library(raster)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(blockCV)
library(sp)
library(dismo)
library(ggplot2)

# Population size from density predictions ####
pred_abs_2011<- brick("0_data/1_processed/prediction dataset/abs2011_250m.grd")
load("2_BRT_outputs/outputs.RData")

library(gbm)
start_time <- Sys.time()
rast <-  predict(pred_abs_2011,
                 brt5,
                 type = "response",
                 n.trees = brt5$n.trees)
end_time <- Sys.time()
end_time - start_time
plot(rast) # density is singing males/ha; rast currently has a temp file dependency

# need to consider only the raster cells that went into the simulations
#load("E:/CWS Wood Thrush Contract/CHID previous work Francisco/CHID regional NS BRT/Nova Scotia Landscape simulation results/Prediction raster/birddensityRasters_NovaScotia_baseline_BudwormBaselineFire_1_CAWA.RData")
load("0_data/1_processed/Prediction rasters 2100/birddensityr_meansd_BS_NovaScotia_baseline_BudwormBaselineFire_1_2100_CAWA.RData")
plot(rasterstack_meansd$mean)#mean density distribution in 2100 AD from one scenario
ncell(rasterstack_meansd$mean)
#2047212 cells in raster
ncell(rasterstack_meansd$mean[!is.na(rasterstack_meansd$mean)])
#418032 cells in raster with non-missing values

rastRES<-resample(rast,rasterstack_meansd$mean)
rast2<-mask(rastRES,rasterstack_meansd$mean)
writeRaster(rast2, filename="0_data/1_processed/Rasters for Zonation/PresentPredictedDensity_mean.tif", format='GTiff', overwrite=TRUE)
writeRaster(rast2, filename="0_data/1_processed/Zonation Scenarios Run/Current Density Only/PresentPredictedDensity_mean.tif", format='GTiff', overwrite=TRUE)
writeRaster(rast2, filename="0_data/1_processed/Zonation Scenarios Run/Oct 2021 BestCaseScenario/PresentPredictedDensity_mean.tif", format='GTiff', overwrite=TRUE)
writeRaster(rast2, filename="0_data/1_processed/Zonation Scenarios Run/Oct 2021 MediumCaseScenario/PresentPredictedDensity_mean.tif", format='GTiff', overwrite=TRUE)
writeRaster(rast2, filename="0_data/1_processed/Zonation Scenarios Run/Oct 2021 WorstCaseScenario/PresentPredictedDensity_mean.tif", format='GTiff', overwrite=TRUE)

# Multiplying density values by 6.25 (hectares in a 250-250 pixel) to get abundance for each cell and overall population size

density_brt5_250m<-rast2*6.25
popsize<-cellStats(density_brt5_250m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE
#[1] 38282.82

density_brt5_250m_full<-rast*6.25
popsize_full<-cellStats(density_brt5_250m_full,stat=sum,na.rm=T)
#[1] 49808.65

# alternative is to obtain 100 random Poisson draws using cell density as rate parameter:
v1<-values(density_brt5_250m)[!is.na(values(density_brt5_250m))]
abundance_brt5<-matrix(NA,length(v1),100)
for(i in 1:nrow(abundance_brt5)){
  abundance_brt5[i,]<- rpois(100,v1[i])
}
## mean of sums across the 100 draws
mean(colSums(abundance_brt5)) 


# Same procedure for upper and lower CI predictions  
upper<-raster("2_BRT_outputs/GFsigma750m_new/confint/confint_upper.tif") 
upperRES<-resample(upper, rasterstack_meansd$mean)
upper2<-mask(upperRES,rasterstack_meansd$mean)
upper_brt5_ss<-upper2*6.25
popsize.upp<-cellStats(upper_brt5_ss,stat=sum,na.rm=T)
#[1] 55367.32

upper_brt5_ss_full<-upper*6.25
popsize.upp_full<-cellStats(upper_brt5_ss_full,stat=sum,na.rm=T)
#[1] 71621.7

# v2<-values(upper_brt5_250m)[!is.na(values(upper_brt5_250m))]
# abundance_upper_brt5<-matrix(NA,length(v2),100)
# for(i in 1:nrow(abundance_upper_brt5)){
#   abundance_upper_brt5[i,]<- rpois(100,v2[i])
# }
# mean(colSums(abundance_upper_brt5))

lower<-raster("2_BRT_outputs/GFsigma750m_new/confint/confint_lower.tif")
lowerRES<-resample(lower, rasterstack_meansd$mean)
lower2<-mask(lowerRES,rasterstack_meansd$mean)
lower_brt5_ss<-lower2*6.25
popsize.low<-cellStats(lower_brt5_ss,stat=sum,na.rm=T)
#[1] 21198.32

lower_brt5_ss_full<-lower*6.25
popsize.low_full<-cellStats(lower_brt5_ss_full,stat=sum,na.rm=T)
#[1] 27995.59

# v3<-values(lower_brt5_250m)[!is.na(values(lower_brt5_250m))]
# abundance_lower_brt5<-matrix(NA,length(v3),100)
# for(i in 1:nrow(abundance_lower_brt5)){
#   abundance_lower_brt5[i,]<- rpois(100,v3[i])
# }
# mean(colSums(abundance_lower_brt5))

# to obtain custom CI (other than 90%):
upper3<- calc(confintbrt5[[-1]],function(x) {quantile(x, probs = 0.95, na.rm = TRUE)})
upper3RES<-resample(upper3, rasterstack_meansd$mean)
upper3<-mask(upper3RES, rasterstack_meansd$mean)
upper3_ss<-upper3*6.25
popsize.upp<-cellStats(upper3_ss,stat=sum,na.rm=T)
#55367.32

lower3<- calc(confintbrt5[[-1]],function(x) {quantile(x, probs = 0.05, na.rm = TRUE)})
lower3RES<-resample(lower3, rasterstack_meansd$mean)
lower3<-mask(lower3RES, rasterstack_meansd$mean)
lower3_ss<-lower3*6.25
popsize.low<-cellStats(lower3_ss,stat=sum,na.rm=T)
#21198.32

# cell level SDs 
bootsamples<-confintbrt5[[-1]]
names(bootsamples)
bootsamplesRES<-resample(bootsamples,rasterstack_meansd$mean)
bootsamples_masked<-mask(bootsamplesRES,rasterstack_meansd$mean)
SDpreds<-calc(bootsamples_masked,fun=sd,na.rm=T)

# test for outliers with very high SD. 
SDpreds
#If necessary, set those values to be equal to the 99% quantile
#values(SDpreds)[which(values(SDpreds)>quantile(values(SDpreds),0.9995,na.rm=T))]<-quantile(values(SDpreds),0.9995,na.rm=T)

plot(SDpreds)
writeRaster(SDpreds, filename="0_data/1_processed/Rasters for Zonation/PresentPredictedDensity_SD.tif", format='GTiff', overwrite=TRUE)
writeRaster(SDpreds, filename="0_data/1_processed/Zonation Scenarios Run/Current Density Only/PresentPredictedDensity_SD.tif", format='GTiff', overwrite=TRUE)
writeRaster(SDpreds, filename="0_data/1_processed/Zonation Scenarios Run/Oct 2021 BestCaseScenario/PresentPredictedDensity_SD.tif", format='GTiff', overwrite=TRUE)
writeRaster(SDpreds, filename="0_data/1_processed/Zonation Scenarios Run/Oct 2021 MediumCaseScenario/PresentPredictedDensity_SD.tif", format='GTiff', overwrite=TRUE)
writeRaster(SDpreds, filename="0_data/1_processed/Zonation Scenarios Run/Oct 2021 WorstCaseScenario/PresentPredictedDensity_SD.tif", format='GTiff', overwrite=TRUE)

popsizeCIs<-c(estimate=popsize,lower=popsize.low,upper=popsize.upp)

# Current population size probability  ####

bootpopsizes<-rep(NA,250)
for(i in 1:250){
  bootpopsizes[i]<-cellStats(bootsamples_masked[[i]]*6.25,stat=sum,na.rm=T)
}


bootpopsizes

mean(bootpopsizes)#35879.16
median(bootpopsizes)#35594.65
sd(bootpopsizes)  #3906.049
###

#with normal distribution:
poprange<-seq(15000,70000,by=1000)
id.dist<-pnorm(poprange,mean=mean(bootpopsizes),sd=sd(bootpopsizes),lower.tail = F)
id.df<-data.frame("Pop.range"=poprange,"Probability"=id.dist,Distribution="normal")
library(ggplot2)
plot1<-ggplot(id.df, aes(x = Pop.range, y = Probability)) + geom_point()+ geom_vline(xintercept = popsize,  color = "blue", size=0.8)
ggsave(plot1, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot1_pnorm_bootstrappedpopnsize.png", units="in", width=10, height=8)

#with gamma distribution:
findGamma1<-function(scale.init,shape.init,low,upp){
  mat<-expand.grid(scale=runif(1000,min=scale.init[1],max=scale.init[2]),shape=runif(1000,min=shape.init[1],max=shape.init[2]))
  mat[,3:4]<-t(apply(mat,1,FUN = function(x){qgamma(p=c(0.05,0.95),shape=x[2],scale=x[1])}))
  mat$distances<-pointDistance(p1=mat[,3:4],p2=c(low,upp),lonlat = F)
  out1<-mat[which.min(mat$distances),]
  
  scale.init2<-unlist(c(out1[1]-(out1[1]*0.25),out1[1]+(out1[1]*0.25)))
  shape.init2<-unlist(c(out1[2]-(out1[2]*0.25),out1[2]+(out1[2]*0.25)))
  
  mat2<-expand.grid(scale=runif(1000,min=scale.init2[1],max=scale.init2[2]),shape=runif(1000,min=shape.init2[2],max=shape.init2[2]))
  mat2[,3:4]<-t(apply(mat2,1,FUN = function(x){qgamma(p=c(0.05,0.95),shape=x[2],scale=x[1])}))
  mat2$distances<-pointDistance(p1=mat2[,3:4],p2=c(low,upp),lonlat = F)
  
  mat3<-rbind(mat,mat2)
  colnames(mat3)[3:4]<-c("lowerCL_0.5","upperCL_0.95")
  return(mat3[which.min(mat3$distances),])
}


GammaParamsCurrent<-findGamma1(scale.init=c(2000,60000),shape.init = c(0.25,15),upp=popsize.upp,low=popsize.low)
GammaParamsCurrent
#          scale    shape lowerCL_0.5 upperCL_0.95 distances
#646095 2981.047 12.28146    21280.69     55316.66  96.70216

id.dist.gamma<-pgamma(poprange,shape=GammaParamsCurrent$shape,scale=GammaParamsCurrent$scale,lower.tail = F)
id.df.gamma<-data.frame("Pop.range"=poprange,"Probability"=id.dist.gamma,Distribution="gamma")


ycurrentprednormal<-pnorm(popsize,mean=mean(bootpopsizes),sd=sd(bootpopsizes),lower.tail = F)
ycurrentpredgamma<-pgamma(popsize,shape=GammaParamsCurrent$shape,scale=GammaParamsCurrent$scale,lower.tail = F)


library(ggplot2)
plot2<-ggplot(rbind(id.df,id.df.gamma)) + 
  geom_point(aes(x = Pop.range, y = Probability,color=Distribution))+ 
  geom_errorbarh(aes(xmax=popsize.upp,xmin=popsize.low,y=ycurrentpredgamma,height=0.03),color="#F8766D")+#"#00BFC4"
  geom_point(x = popsize,y=ycurrentpredgamma)+
  geom_errorbarh(aes(xmax=popsize.upp,xmin=popsize.low,y=ycurrentprednormal,height=0.03),color="#00BFC4")+#"#F8766D"
  geom_point(x = popsize,y=ycurrentprednormal)+  
  labs(x="N",y="Probability (population size >= N)")+
  annotate("text", x= 38000, y = 0.57,hjust=0, label = paste0("Model prediction (90% CI) = ",round(popsize,0)," (",round(popsize.low,0)," - ",round(popsize.upp,0),")"),size=4)
#Assuming that present population size from confidence interval
#is normally distributed, calculates probability that population 
#is >= (at least) a given population size
ggsave(plot2, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot2_prob_specificbootstrappedpopnsize_gamma.vs.normal.png", units="in", width=10, height=8)

plot3<-ggplot(rbind(id.df)) + 
  geom_point(aes(x = Pop.range, y = Probability),color="#F8766D")+ 
  #geom_errorbarh(aes(xmax=popsize.upp,xmin=popsize.low,y=ycurrentpredgamma,height=0.03),color="#00BFC4")+
  #geom_point(x = popsize,y=ycurrentpredgamma)+
  geom_errorbarh(aes(xmax=popsize.upp,xmin=popsize.low,y=ycurrentprednormal,height=0.03),color="#F8766D")+
  geom_point(x = popsize,y=ycurrentprednormal)+  
  labs(x="N",y="Probability (population size >= N)")+
  annotate("text", x= 38000, y = 0.57,hjust=0, label = paste0("Model prediction (90% CI) = ",round(popsize,0)," (",round(popsize.low,0)," - ",round(popsize.upp,0),")"),size=4)
ggsave(plot3, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot3_prob_specificbootstrappedpopnsize_just.normal.png", units="in", width=10, height=8)

plot4<-ggplot(rbind(id.df.gamma)) + 
  geom_point(aes(x = Pop.range, y = Probability),color="#00BFC4")+ 
  geom_errorbarh(aes(xmax=popsize.upp,xmin=popsize.low,y=ycurrentpredgamma,height=0.03),color="#00BFC4")+
  geom_point(x = popsize,y=ycurrentpredgamma)+
  #geom_errorbarh(aes(xmax=popsize.upp,xmin=popsize.low,y=ycurrentprednormal,height=0.03),color="#F8766D")+
  #geom_point(x = popsize,y=ycurrentprednormal)+  
  labs(x="N",y="Probability (population size >= N)")+
  annotate("text", x= 38000, y = 0.57,hjust=0, label = paste0("Model prediction (90% CI) = ",round(popsize,0)," (",round(popsize.low,0)," - ",round(popsize.upp,0),")"),size=4)
ggsave(plot4, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot4_prob_specificbootstrappedpopnsize_just.gamma.png", units="in", width=10, height=8)

#Check with Francisco on this part:
#Assuming that present population size from confidence interval
#is gamma distributed, calculates probability that population 
#is >= (at least) a given population size

#### Future Population size - current conditions ####
# trend from BBS (Smith et al 2014), CAWA in Nova Scotia
# From "Canada Warbler trends"
trends<- c(long_trend = -3.09, # long term trend (>40 years)
                    long_trend_lower= -4.47,#2.5% quantile
                    long_trend_upper= -1.81,#97.5% quantile
                    short_trend = -2.74, # short term trend (10 years) 
                    short_trend_lower =-8.26,
                    short_trend_upper = 2.70)

# Population growth model - also from Smith et al 2014

popgrowth<-function(data){
  years<-data[1]
  N0<-data[2]
  trend<-data[3]
  lower<-data[4]
  upper<-data[5]

  est<-N0*(1+trend/100)^years
  low<-N0*(1+lower/100)^years
  upp<-N0*(1+upper/100)^years
  out<-c(est=est,low=low,upp=upp)
  out
  }

year.range<-31#Predict from 2019 to 2050

df<-data.frame(years=rep(seq(1:year.range),6),N0=rep(popsizeCIs,each=2*year.range),trend=c(rep(trends[1],year.range),rep(trends[4],year.range)),lower=c(rep(trends[2],year.range),rep(trends[5],year.range)),upper=c(rep(trends[3],year.range),rep(trends[6],year.range)))
df[,6:8]<-t(apply(df,1,popgrowth))
names(df)[6:8]<-c("Ni","Ni_lower", "Ni_upper")
df$group<-c(rep("Estimate",2*year.range),rep("2.5%CI",2*year.range),rep("97.5%CI",2*year.range))
df$group2<-rep(c(rep("long",year.range),rep("short",year.range)),3)  
df

df_long<-subset(df,group2=="long")
row.names(df_long)<-seq(1:nrow(df_long))
df_short<-subset(df,group2=="short")
row.names(df_short)<-seq(1:nrow(df_short))

plot5<-ggplot(data=df_long)+
  geom_ribbon(mapping=aes(x=years,ymin=Ni_lower,ymax=Ni_upper,fill=group), alpha=0.2)+
  geom_line(mapping=aes(x=years,y=Ni,group=group,color=group),size=1)+ 
  #theme(legend.title=element_blank())+ 
  guides(fill = guide_legend(reverse=TRUE),color=guide_legend(reverse=TRUE))+
  labs(x = "Years (2019 - 2050)", y="Population size", fill="Current population",color="Current population")+
  xlim(1,year.range)+
  ylim(0,100000)+
  annotate("text", x= 10, y = 75000, label = ("Long term trend = -3.08 (-4.48, -1.81)"),size=5)
ggsave(plot5, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot5_longtermBBStrends.to2050.png", units="in", width=10, height=8)

plot6<-ggplot(data=df_short)+
  geom_ribbon(mapping=aes(x=years,ymin=Ni_lower,ymax=Ni_upper,fill=group), alpha=0.2)+
  geom_line(mapping=aes(x=years,y=Ni,group=group,color=group),size=1)+ 
  #theme(legend.title=element_blank())+ 
  guides(fill = guide_legend(reverse=TRUE),color=guide_legend(reverse=TRUE))+
  labs(x = "Years (2019 - 2050)", y="Population size", fill="Current population",color="Current population")+
  #xlim(1,year.range)+
  #ylim(0,100000)+
  annotate("text", x= 10, y = 100000, label = ("Short term trend = -2.74 (-8.26, 2.70)"),size=5)
ggsave(plot6, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot6_shorttermBBStrends.to2050.png", units="in", width=10, height=8)

# # find out what year the current estimates most relate to, based on year of avian data:
#Lionel: this part was used to determine an appropriate reference year
#yearsdata df should be loaded for one of the ggplots later on
load("0_data/0_raw/BAM_data_package_August2019.RData")
yearsdata<-PKEYcombo$YEAR[match(datcombo$PKEY,PKEYcombo$PKEY)]
yearsdata<-as.data.frame(t(table(yearsdata)))[,2:3]
names(yearsdata)<-c("Year","Freq")
yearsdata$Year<-as.numeric(as.character(yearsdata$Year))
str(yearsdata)

median(PKEYcombo$YEAR[match(datcombo$PKEY,PKEYcombo$PKEY)])
#2006
mean(PKEYcombo$YEAR[match(datcombo$PKEY,PKEYcombo$PKEY)])
#2004.624
plot(table(PKEYcombo$YEAR[match(datcombo$PKEY,PKEYcombo$PKEY)]),ylab="Frequency")

# 2006 is median, but use 2007 to include in short term trend
# Lionel Change this
BBS_AI <- read.csv("0_data/0_raw/BBS_annual_indices_CAWA_NS_2019.csv")
#annual indices downloaded from BBS website

AI2007<-BBS_AI[which(BBS_AI$year==2007&BBS_AI$timeFrame=="Long-term"),7:9]

df_long

newdf<-data.frame(year=c(1970:2050),annualIndex=NA,lower=NA,upper=NA,psize=NA,psizeLow=NA,psizeUpp=NA)
newdf[1:50,2:4]<-BBS_AI[1:50,7:9]
#changed from 1:48 to 1:50 since we now have trend data from 1970-2019 (50 years including 1970)

for(i in c(1:50)){
  newdf[i,5]<-newdf[i,2]*popsizeCIs[1]/newdf[38,2]
  newdf[i,6]<-newdf[i,2]*popsizeCIs[2]/newdf[38,2]
  newdf[i,7]<-newdf[i,2]*popsizeCIs[3]/newdf[38,2]
}
#changed from 1:48 to 1:50 since we now have trend data to 2019
newdf
#add 31 more rows for years 2020-2050
#significance of numbers 51:81 is rows for years 2020-2050
for(i in 51:81){
  newdf[i,5]<-newdf[50,5]*(1+trends[1]/100)^(i-50)
  newdf[i,6]<-newdf[50,6]*(1+trends[1]/100)^(i-50)
  newdf[i,7]<-newdf[50,7]*(1+trends[1]/100)^(i-50)

  newdf[i,2]<-round(AI2007[1]*newdf[i,5]/newdf[38,5],3)
  newdf[i,3]<-round(AI2007[1]*newdf[i,6]/newdf[38,5],3)
  newdf[i,4]<-round(AI2007[1]*newdf[i,7]/newdf[38,5],3)
#newdf[38,5] refers to our reference year of 2007

}
#changed 49 to 51 and 48 to 50
#significance of numbers 51:81 is rows for years 2020-2040
plot7<-ggplot(data=newdf[1:81,])+
  geom_ribbon(aes(x=year,ymin=upper,ymax=lower),alpha=0.3)+
  geom_line(aes(x=year,y=annualIndex))+
  geom_vline(xintercept = 2007,  color = "blue", size=0.5)+
  geom_vline(xintercept = 2018,  color = "red", size=0.5)
ggsave(plot7, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot7_longtermannualindexBBStrends.to2050.png", units="in", width=10, height=8)

#significance of numbers 51:81 is rows for years 2020-2050
plot8<-ggplot(data=newdf[1:81,])+
  geom_ribbon(aes(x=year,ymin=psizeLow,ymax=psizeUpp),alpha=0.3)+
  geom_line(aes(x=year,y=psize))+
  geom_vline(xintercept = 2007,  color = "blue", size=0.5)+
  geom_vline(xintercept = 2018,  color = "red", size=0.5)
ggsave(plot8, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot8_longtermpopnsizeBBStrends.to2050.png", units="in", width=10, height=8)

#newdf[72:117,]<-NA
#newdf$group<-c(rep("Trend estimate",71),rep("2.5%CI",23),rep("97.5%CI",23))

#in original script, these 46 new lines were for 2 times the number of 
#rows required for 2018-2040, because last year with trend data was 2017
#and we were predicting to 2040

#now last year of trend data is 2019 and we are predicting to 2050
#32 rows for 2019-2050*2 = 64 rows required: row 82 + 63 more rows (to 145)
#significance of numbers 81:117 is rows for years 2051-2076
newdf[82:145,]<-NA
newdf$group<-c(rep("Trend estimate",81),rep("2.5%CI",32),rep("97.5%CI",32))

newdf[82:145,1]<-rep(2019:2050,times=2)

#Line 50 in newdf corresponds to year 2019 (changed from line 48 for 2017)
#Line 38 in newdf corresponds to reference year 2007 (do not change)
#not sure about number 68
#82:113 is 32 rows for 31 year difference (2050-2019)
for(i in 82:113){
  newdf[i,5]<-newdf[50,5]*(1+trends[2]/100)^(newdf$year[i]-2019)
  newdf[i,6]<-newdf[50,6]*(1+trends[2]/100)^(newdf$year[i]-2019)
  newdf[i,7]<-newdf[50,7]*(1+trends[2]/100)^(newdf$year[i]-2019)
  
  newdf[i,2]<-round(AI2007[1]*newdf[i,5]/newdf[38,5],3)
  newdf[i,3]<-round(AI2007[1]*newdf[i,6]/newdf[38,5],3)
  newdf[i,4]<-round(AI2007[1]*newdf[i,7]/newdf[38,5],3)
}
newdf

for(i in 114:145){
  newdf[i,5]<-newdf[50,5]*(1+trends[3]/100)^(newdf$year[i]-2019)
  newdf[i,6]<-newdf[50,6]*(1+trends[3]/100)^(newdf$year[i]-2019)
  newdf[i,7]<-newdf[50,7]*(1+trends[3]/100)^(newdf$year[i]-2019)
  
  newdf[i,2]<-round(AI2007[1]*newdf[i,5]/newdf[38,5],3)
  newdf[i,3]<-round(AI2007[1]*newdf[i,6]/newdf[38,5],3)
  newdf[i,4]<-round(AI2007[1]*newdf[i,7]/newdf[38,5],3)
}
newdf
#generates population size estimates for 1970 - 2050

plot9<-ggplot(data=newdf)+
  geom_ribbon(aes(x=year,ymin=upper,ymax=lower,fill=group),alpha=0.2)+
  geom_line(aes(x=year,y=annualIndex,color=group))+
  geom_vline(xintercept = 2007,  size=0.5)+
  geom_segment(x=2018,y=0.7,xend=2037,yend=0.7,size=0.5,arrow = arrow(angle=90,ends="both",length=unit(0.08,"inches")))+
  guides(fill = guide_legend(reverse=TRUE),color=guide_legend(reverse=TRUE))+
  labs(x = "Years", y="Annual Index", fill="",color="")+
  annotate("text", x= 2006, y = 2,angle=90, label = ("BRT model reference year"),size=4)+
  annotate("text", x= 2028, y = 0.8, label = ("Predictions with BBS trend (2019)"),size=4)

ggsave(plot9, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot9_longtermtrendestimateannualindexBBStrends.to2050.png", units="in", width=10, height=8)
###Should I change this to be predictions with BBS trend from 2019?
library(scales)

plot10<-ggplot(data=newdf)+
  geom_ribbon(aes(x=year,ymin=psizeLow,ymax=psizeUpp,fill=group),alpha=0.2)+
  geom_line(aes(x=year,y=psize,color=group))+
  geom_vline(xintercept = 2007,  size=0.5)+
  geom_segment(x=2018,y=175000,xend=2040,yend=175000,size=0.5,arrow = arrow(angle=90,ends="both",length=unit(0.08,"inches")))+
  guides(fill = guide_legend(reverse=TRUE),color=guide_legend(reverse=TRUE))+
  labs(x = "Years", y="Population size", fill="",color="")+
  scale_y_continuous(labels = comma)+
  annotate("text", x= 2006, y = 500000,angle=90, label = ("BRT model reference year (2007)"),size=4)+
  annotate("text", x= 2028, y = 200000, label = ("Predictions with BBS trend (2019)"),size=4)+
  geom_rug(data=yearsdata, aes(x=Year,y=Freq),sides="b", alpha=0.5, position="jitter")

ggsave(plot10, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot10_longtermtrendestimateannualindexBBStrends.to2050.withrugplot.png", units="in", width=10, height=8)

# Population size trajectory and future predictions with BBS long-term trend

newdf2<-subset(newdf,group=="Trend estimate")
#newdf2[49:71,"psizeLow"]<-newdf[72:94,"psizeLow"]
#newdf2[49:71,"psizeUpp"]<-newdf[95:117,"psizeUpp"]
newdf2[51:81,"psizeLow"]<-newdf[83:113,"psizeLow"]#years 2020-2050 (from rows 83:113 in newdf)
newdf2[51:81,"psizeUpp"]<-newdf[114:144,"psizeUpp"]#years 2020-2050 (from rows 114:144 in newdf)
#Change 49 to 51 and 71 to 81?

jitter <- position_jitter(width = 0.05, height = 1)

plot11<-ggplot(data=newdf2)+
  geom_ribbon(aes(x=year,ymin=psizeLow,ymax=psizeUpp),fill="blue",alpha=0.2)+
  geom_line(aes(x=year,y=psize),color="blue")+
  geom_vline(xintercept = 2007,  size=0.5,linetype="dashed")+
  geom_errorbarh(aes(xmax=2050,xmin=2018,y=126000,height=20000))+
  guides(fill = guide_legend(reverse=TRUE),color=guide_legend(reverse=TRUE))+
  labs(x = "Years", y="Population size (males)", fill="",color="")+
  scale_y_continuous(labels = comma)+
  annotate("text", x= 2008, y = 400000,hjust=0, label = paste0("BRT model reference year (2007) \n", paste0("Estimate (90% CI) = ",round(popsize,0)," (",round(popsize.low,0)," - ",round(popsize.upp,0),")")),size=4)+
  annotate("text", x= 2029, y = 155000, label = ("Predictions with BBS long-term trend (2019): \n -3.09 (-4.47, -1.81)"),size=4)+
  geom_rug(data=yearsdata, aes(x=Year,y=Freq),length=unit(yearsdata$Freq/50000,"npc"),sides="b", alpha=0.5, position=jitter)
#Changed from 2018 to 2020 since trend is now for 1970-2019

ggsave(plot11, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot11_longtermtrendestimatepopnsizeBBStrends.to2050.withrugplot.png", units="in", width=10, height=8)


# Population size trajectory and future predictions with BBS short-term trend (10 years)
newdf3<-data.frame(year=c(2020:2050),psize=NA,psizeLow=NA,psizeUpp=NA)
newdf3<-rbind(newdf3,newdf3,newdf3)
newdf3$group<-c(rep("Trend estimate",31),rep("2.5%CI",31),rep("97.5%CI",31))
#Changed from 2018 to 2020 since trend is now for 1970-2019
#Changed rep("Trend estimate",23 for 2017-2040) to rep("Trend estimate",31 for 2019-2050), etc.
#
for(i in 1:31){
  newdf3[i,2]<-newdf[50,5]*(1+trends[4]/100)^(newdf3$year[i]-2019)
  newdf3[i,3]<-newdf[50,6]*(1+trends[4]/100)^(newdf3$year[i]-2019)
  newdf3[i,4]<-newdf[50,7]*(1+trends[4]/100)^(newdf3$year[i]-2019)
  }
#Changed 1:23 to 1:31, 48 to 50, 2017 to 2019 since we are now predicting for 2019-2050

for(i in 32:62){
  newdf3[i,2]<-newdf[50,5]*(1+trends[5]/100)^(newdf3$year[i]-2019)
  newdf3[i,3]<-newdf[50,6]*(1+trends[5]/100)^(newdf3$year[i]-2019)
  newdf3[i,4]<-newdf[50,7]*(1+trends[5]/100)^(newdf3$year[i]-2019)
}
#Changed 24:46 to 32:62, 48 to 50, 2017 to 2019 since we are now predicting for 2019-2050
for(i in 63:93){
  newdf3[i,2]<-newdf[50,5]*(1+trends[6]/100)^(newdf3$year[i]-2019)
  newdf3[i,3]<-newdf[50,6]*(1+trends[6]/100)^(newdf3$year[i]-2019)
  newdf3[i,4]<-newdf[50,7]*(1+trends[6]/100)^(newdf3$year[i]-2019)
}
#Changed 47:69 to 63:93, 48 to 50, 2017 to 2019 since we are now predicting for 2020-2050
newdf3

newdf4<-newdf2
#Changed 49:71 to 51:81 because we are now using short-term trends to predict 2020-2050
newdf4[51:81,"psize"]<-newdf3[1:31,"psize"]
newdf4[51:81,"psizeLow"]<-newdf3[32:62,"psizeLow"]
newdf4[51:81,"psizeUpp"]<-newdf3[63:93,"psizeUpp"]

plot12<- ggplot(data=newdf4)+
  geom_ribbon(aes(x=year,ymin=psizeLow,ymax=psizeUpp),fill="darkgreen",alpha=0.2)+
  geom_line(aes(x=year,y=psize),color="darkgreen")+
  geom_vline(xintercept = 2007,  size=0.5,linetype="dashed")+
  geom_errorbarh(aes(xmax=2050,xmin=2020,y=210000,height=20000))+
  guides(fill = guide_legend(reverse=TRUE),color=guide_legend(reverse=TRUE))+
  labs(x = "Years", y="Population size (males)", fill="",color="")+
  scale_y_continuous(labels = comma)+
  annotate("text", x= 2008, y = 650000,hjust=0, label = paste0("BRT model reference year (2007) \n", paste0("Estimate (90% CI) = ",round(popsize,0)," (",round(popsize.low,0)," - ",round(popsize.upp,0),")")),size=4)+
  annotate("text", x= 2029, y = 240000, label = ("Predictions with BBS short-term trend (2019): \n -2.74 (-8.26, 2.70)"),size=4)+
  geom_rug(data=yearsdata, aes(x=Year,y=Freq),length=unit(yearsdata$Freq/50000,"npc"),sides="b", alpha=0.5, position=jitter)+
  coord_cartesian(ylim = c(0, 675000)) 
ggsave(plot12, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot12_shorttermtrendestimatepopnsizeBBStrends.to2050.withrugplot.png", units="in", width=10, height=8)
  

library(gridExtra)
plot13<-grid.arrange(plot11,plot12,nrow=2)
ggsave(plot13, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot13_longANDshorttermtrendestimatepopnsizeBBStrends.to2050.withrugplot.png", units="in", width=10, height=8)

save.image(file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/.RData")
# Compare future pop.size based on trend with that from simulations in LANDIS ####
load("2_BRT_outputs/GFsigma750m_new/bbs and landis trends/.RData")
load("0_data/1_processed/DensityTotal.df.RData")

head(DensityTotal.df)

DensityTotal.df$Popsize<-DensityTotal.df$MeanDensity*418032*6.25
#mean density (#males/ha) *#ha/250-m cell *#cells with non-missing values

saveRDS(DensityTotal.df,"2_BRT_outputs/GFsigma750m_new/bbs and landis trends/bootstrap_predictions2100.R")
write.csv(DensityTotal.df, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/bootstrap_predictions2100.csv")

bootstrap_predictions2100<-read.csv("2_BRT_outputs/GFsigma750m_new/bbs and landis trends/bootstrap_predictions2100.csv", header=TRUE)
str(bootstrap_predictions2100)
bootstrap_predictions2050<-bootstrap_predictions2100[bootstrap_predictions2100$Year==2050,]
bootstrap_predictions2050$Sc_x_Tr<-paste0(bootstrap_predictions2050$scenario,"_",bootstrap_predictions2050$treatment)#instead of treatment

getLandisPreds2050<-function(scenario){
  Sc_x_Tr<-scenario
  bootstrap_predictions2050<-bootstrap_predictions2050[bootstrap_predictions2050$Sc_x_Tr==Sc_x_Tr,]
  
  #filelist<-list.files("0_data/",pattern=scenario)
  #Change pattern=scenario? No rasters or files have "scenario" in their names
  # preds<-rep(NA,5)
  # for(i in 1:length(filelist)){
  #   load(paste0("0_data/",filelist[i]))
  #   landispreds2050<-PredictBirdsp.l[[2]] # 2 is for 2050
  #   
  #   landispreds2050<-landispreds2050*6.25  # Multiplying density values by 6.25 (hectars in a 250-250 pixel) to get abundance for each cell and overall population size
  #   preds[i]<-cellStats(landispreds2050,stat=sum,na.rm=T)
  # }
  preds.out<-bootstrap_predictions2050%>%
    summarize(mean=mean(Popsize),sd=sd(Popsize))#Popsize instead of preds
  #preds.out<-data.frame(mean=mean(preds),sd=sd(preds))#Popsize instead of preds
  
  return(preds.out)
  
}
#make sure there are no TIF files stored in this folder. Only RData files
scenarios<-getLandisPreds2050("baseline_BudwormBaselineFire")#baseline_BudwormBaselineFire_
#imports the 5 RData files for this Landis scenario, corresponding to different simulation runs
#generates mean population size and sd
scenarios[2,]<-getLandisPreds2050("baseline_BudwormBaselineFireEBFMHarvest")
scenarios[3,]<-getLandisPreds2050("baseline_BudwormBaselineFireHighCPRSHarvest")
scenarios[4,]<-getLandisPreds2050("baseline_BudwormBaselineFireHighPartialHarvest")
scenarios[5,]<-getLandisPreds2050("baseline_BudwormBaselineFireLowCPRSHarvest")
scenarios[6,]<-getLandisPreds2050("baseline_BudwormBaselineFireLowPartialHarvest")
#one by one adds mean and sd to "scenarios"

#Drop RCP26?
#scenarios[7,]<-getLandisPreds2050("RCP26_GrowthBudwormProjectedFire_")
#scenarios[8,]<-getLandisPreds2050("RCP26_GrowthBudwormProjectedFireEBFMHarvest_")
#scenarios[9,]<-getLandisPreds2050("RCP26_GrowthBudwormProjectedFireHighCPRSHarvest_")
#scenarios[10,]<-getLandisPreds2050("RCP26_GrowthBudwormProjectedFireHighPartialHarvest_")
#scenarios[11,]<-getLandisPreds2050("RCP26_GrowthBudwormProjectedFireLowCPRSHarvest_")
#scenarios[12,]<-getLandisPreds2050("RCP26_GrowthBudwormProjectedFireLowPartialHarvest_")

scenarios[7,]<-getLandisPreds2050("RCP45_GrowthBudwormProjectedFire")
scenarios[8,]<-getLandisPreds2050("RCP45_GrowthBudwormProjectedFireEBFMHarvest")
scenarios[9,]<-getLandisPreds2050("RCP45_GrowthBudwormProjectedFireHighCPRSHarvest")
scenarios[10,]<-getLandisPreds2050("RCP45_GrowthBudwormProjectedFireHighPartialHarvest")
scenarios[11,]<-getLandisPreds2050("RCP45_GrowthBudwormProjectedFireLowCPRSHarvest")
scenarios[12,]<-getLandisPreds2050("RCP45_GrowthBudwormProjectedFireLowPartialHarvest")

scenarios[13,]<-getLandisPreds2050("RCP85_GrowthBudwormProjectedFire")
scenarios[14,]<-getLandisPreds2050("RCP85_GrowthBudwormProjectedFireEBFMHarvest")
scenarios[15,]<-getLandisPreds2050("RCP85_GrowthBudwormProjectedFireHighCPRSHarvest")
scenarios[16,]<-getLandisPreds2050("RCP85_GrowthBudwormProjectedFireHighPartialHarvest")
scenarios[17,]<-getLandisPreds2050("RCP85_GrowthBudwormProjectedFireLowCPRSHarvest")
scenarios[18,]<-getLandisPreds2050("RCP85_GrowthBudwormProjectedFireLowPartialHarvest")

# adding columns with scenario names
filelist<-list.files("0_data/1_processed/Prediction rasters 2100/")

# scenario.names<-rep(NA,18)
# for(i in 1:18 ){
#   splits<-unlist(strsplit(filelist[seq(1,length(filelist),by=5)[i]], split="_"))
#   name.sce<-paste(splits[3],splits[4],sep="_")
#   scenario.names[i]<-name.sce
# }

scenario.names<-c("baseline_BudwormBaselineFire",
                  "baseline_BudwormBaselineFireEBFMHarvest",
                  "baseline_BudwormBaselineFireHighCPRSHarvest",
                  "baseline_BudwormBaselineFireHighPartialHarvest",
                  "baseline_BudwormBaselineFireLowCPRSHarvest",
                  "baseline_BudwormBaselineFireLowPartialHarvest",
                  "RCP45_BudwormBaselineFire",
                  "RCP45_BudwormBaselineFireEBFMHarvest",
                  "RCP45_BudwormBaselineFireHighCPRSHarvest",
                  "RCP45_BudwormBaselineFireHighPartialHarvest",
                  "RCP45_BudwormBaselineFireLowCPRSHarvest",
                  "RCP45_BudwormBaselineFireLowPartialHarvest",
                  "RCP85_BudwormBaselineFire",
                  "RCP85_BudwormBaselineFireEBFMHarvest",
                  "RCP85_BudwormBaselineFireHighCPRSHarvest",
                  "RCP85_BudwormBaselineFireHighPartialHarvest",
                  "RCP85_BudwormBaselineFireLowCPRSHarvest",
                  "RCP85_BudwormBaselineFireLowPartialHarvest")

better.names<-c("Baseline No Harvest",
                  "Baseline EBFM Harvest",
                  "Baseline Historic Clearcut",
                  "Baseline High Partial Cut",
                  "Baseline 50 perc. Historic Clearcut",
                  "Baseline Low Partial Cut",
                  "RCP45 No Harvest",
                  "RCP45 EBFM Harvest",
                  "RCP45 Historic Clearcut",
                  "RCP45 High Partial Cut",
                  "RCP45 50 perc. Historic Clearcut",
                  "RCP45 Low Partial Cut",
                  "RCP85 No Harvest",
                  "RCP85 EBFM Harvest",
                  "RCP85 Historic Clearcut",
                  "RCP85 High Partial Cut",
                  "RCP85 50 perc. Historic Clearcut",
                  "RCP85 Low Partial Cut")

scenarios$scenario<-better.names #instead of scenario.names
scenarios$Climate<-rep(c("Baseline","RCP45","RCP85"),each=6)#"RCP26",
scenarios$Harvest<-rep(c("No Harvest","EBFM Harvest","Historic Clearcut",
                         "High Partial Cut", "50 % Clearcut", "50 % Partial Cut"),3)

scenarios

p_inset<-
  ggplot(data=newdf2)+
  geom_line(aes(x=year,y=psize),color="blue",size=1)+
  guides(fill = guide_legend(reverse=TRUE),color=guide_legend(reverse=TRUE))+
  #scale_y_continuous(labels = comma)+
  geom_pointrange(data=scenarios,mapping=aes(x=2050,y=mean,ymin=mean-1.96*sd,ymax=mean+1.96*sd,color=Climate),position=position_dodge2(width=0.2),alpha=0.8)+ 
  coord_cartesian(xlim=c(2049,2052),ylim=c(53500,63500) )+
  scale_x_continuous(labels=c("","2050","",""))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.ticks = element_blank(),
        legend.position = c(0.75, 0.5)
        )
#changed 39000,58000 to 50000,100000
p_inset

plot14<-plot11+
  geom_pointrange(data=scenarios,mapping=aes(x=2050,y=mean,ymin=mean-1.96*sd,ymax=mean+1.96*sd))+ theme(legend.position = "none")+
  annotation_custom(grob = ggplotGrob(p_inset), xmin=2020, xmax=2050, ymin=200000,ymax=350000)

ggsave(plot14, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot14_longtermBBStrendandLandisTrajectories_estimatepopnsize.to2050.withrugplot.png", units="in", width=10, height=8)

p_insetB<-
  ggplot(data=newdf2)+
  geom_line(aes(x=year,y=psize),color="blue",size=1)+
  guides(fill = guide_legend(reverse=TRUE),color=guide_legend(reverse=TRUE))+
  #scale_y_continuous(labels = comma)+
  geom_pointrange(data=scenarios,mapping=aes(x=2050,y=mean,ymin=mean-1.96*sd,ymax=mean+1.96*sd,color=scenario),position=position_dodge2(width=0.2),alpha=0.8)+ 
  coord_cartesian(xlim=c(2049,2052),ylim=c(56000,63000) )+
  scale_x_continuous(labels=c("","2050","",""))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.ticks = element_blank(),
        legend.title = element_blank(),
        legend.position = c(0.75, 0.5)
  )
#changed 39000,58000 to 50000,100000
p_insetB

p14B<-ggplot(data=newdf2)+
  geom_ribbon(aes(x=year,ymin=psizeLow,ymax=psizeUpp),fill="blue",alpha=0.2)+
  geom_line(aes(x=year,y=psize),color="blue")+
  geom_vline(xintercept = 2007,  size=0.5,linetype="dashed")+
  geom_errorbarh(aes(xmax=2050,xmin=2019,y=85000,height=20000))+
  guides(fill = guide_legend(reverse=TRUE),color=guide_legend(reverse=TRUE))+
  labs(x = "Years", y="Population size (males)", fill="",color="")+
  scale_y_continuous(labels = comma)+
  annotate("text", x= 1970, y = 0, hjust=0, label = paste0("BRT model reference year (2007) \n", paste0("Estimate (90% CI) = ",round(popsize,0)," (",round(popsize.low,0)," - ",round(popsize.upp,0),")")),size=5)+
  annotate("text", x= 2034, y = 110000, label = ("Predictions with BBS long-term trend (2019): \n -3.09 (-4.47, -1.81)"),size=5)+
  geom_rug(data=yearsdata, aes(x=Year,y=Freq),length=unit(yearsdata$Freq/50000,"npc"),sides="b", alpha=0.5, position=jitter)

plot14B<-p14B+
  geom_pointrange(data=scenarios,mapping=aes(x=2050,y=mean,ymin=mean-1.96*sd,ymax=mean+1.96*sd))+ 
  theme(legend.position = "none")+
  annotation_custom(grob = ggplotGrob(p_insetB), xmin=2000, xmax=2055, ymin=150000,ymax=450000)+
  theme(axis.text=element_text(size=16,face="bold"), axis.title=element_text(size=16,face="bold"))

ggsave(plot14B, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot14B_longtermBBStrendandLandisTrajectories_estimatepopnsize.to2050.withrugplot.png", units="in", width=10, height=8)

scenarios$HarvestRecode<-factor(scenarios$Harvest, levels=c("No Harvest", "50 % Partial Cut", "High Partial Cut", 
                                                            "50 % Clearcut", "EBFM Harvest","Historic Clearcut"))
library(viridis)
p_insetC<-
  ggplot(data=newdf2)+
  geom_line(aes(x=year,y=psize),color="blue",size=1)+
  guides(fill = guide_legend(reverse=TRUE),color=guide_legend(reverse=TRUE))+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE)+
  #scale_y_continuous(labels = comma)+
  geom_pointrange(data=scenarios,mapping=aes(x=2050,y=mean,ymin=mean-1.96*sd,ymax=mean+1.96*sd, color=HarvestRecode),position=position_dodge2(width=0.2),alpha=0.8)+
  facet_wrap(~Climate)+ 
  coord_cartesian(xlim=c(2048,2053),ylim=c(56000,63000) )+
  scale_x_continuous(labels=c("","","2050","","",""))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.ticks = element_blank(),
        legend.title = element_blank(),
        legend.position = c(0.84, 0.8)
  )

plot14C<-p14B+
  geom_pointrange(data=scenarios,mapping=aes(x=2050,y=mean,ymin=mean-1.96*sd,ymax=mean+1.96*sd))+ 
  theme(legend.position = "none")+
  annotation_custom(grob = ggplotGrob(p_insetC), xmin=2000, xmax=2055, ymin=150000,ymax=450000)+
  theme(axis.text=element_text(size=16,face="bold"), axis.title=element_text(size=16,face="bold"))

ggsave(plot14C, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot14C_longtermBBStrendandLandisTrajectories_estimatepopnsize.to2050.withrugplot.png", units="in", width=10, height=8)

p14C<-ggplot(data=newdf2)+
  geom_ribbon(aes(x=year,ymin=psizeLow,ymax=psizeUpp),fill="blue",alpha=0.2)+
  geom_line(aes(x=year,y=psize),color="blue")+
  #geom_vline(xintercept = 2007,  size=0.5,linetype="dashed")+
  geom_errorbarh(aes(xmax=2050,xmin=2019,y=85000,height=20000))+
  guides(fill = guide_legend(reverse=TRUE),color=guide_legend(reverse=TRUE))+
  labs(x = "Years", y="Population size (males)", fill="",color="")+
  scale_y_continuous(labels = comma)+
  annotate("text", x= 2034, y = 110000, label = ("Predictions with BBS long-term trend (2019): \n -3.09 (-4.47, -1.81)"),size=5)

plot14D<-p14C+
  geom_pointrange(data=scenarios,mapping=aes(x=2050,y=mean,ymin=mean-1.96*sd,ymax=mean+1.96*sd))+ 
  theme(legend.position = "none")+
  annotation_custom(grob = ggplotGrob(p_insetC), xmin=2000, xmax=2055, ymin=150000,ymax=450000)+
  theme(axis.text=element_text(size=16,face="bold"), axis.title=element_text(size=16,face="bold"))

ggsave(plot14D, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot14D_longtermBBStrendandLandisTrajectories_estimatepopnsize.to2050.withrugplot.png", units="in", width=10, height=8)

p_inset2<-
  ggplot(data=newdf4)+
  geom_line(aes(x=year,y=psize),color="darkgreen")+
  geom_vline(xintercept = 2007,  size=0.5,linetype="dashed")+
  geom_segment(x=2018,y=275000,xend=2050,yend=275000,size=0.5,arrow = arrow(angle=90,ends="both",length=unit(0.08,"inches")))+
  guides(fill = guide_legend(reverse=TRUE),color=guide_legend(reverse=TRUE))+
  labs(x = "Years", y="Population size", fill="",color="")+
  #scale_y_continuous(labels = comma)+
  geom_pointrange(data=scenarios,mapping=aes(x=2050,y=mean,ymin=mean-1.96*sd,ymax=mean+1.96*sd,color=Climate),position=position_dodge2(width=0.2),alpha=0.8)+
  coord_cartesian(xlim=c(2049,2052),ylim=c(50000,65000))+
  scale_x_continuous(labels=c("","2050","",""))+
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.ticks = element_blank(),
        legend.position = c(0.75, 0.5)) 
#changed 39000,200000 to 50000,100000
#p_inset2  
plot15<-plot12+
  geom_pointrange(data=scenarios,mapping=aes(x=2050,y=mean,ymin=mean-1.96*sd,ymax=mean+1.96*sd))+ theme(legend.position = "none")+
  annotation_custom(grob = ggplotGrob(p_inset2), xmin=2020, xmax=2050, ymin=400000,ymax=600000)

ggsave(plot15, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot15_shorttermBBStrendandLandisTrajectories_estimatepopnsize.to2050.withrugplot.png", units="in", width=10, height=8)


# Future population size probability ####
# long trend #
future.pop<-newdf2[which(newdf2$year=="2050"),"psize"] ###

future.pop.upp<-newdf2[which(newdf2$year=="2050"),"psizeUpp"]
future.pop.low<-newdf2[which(newdf2$year=="2050"),"psizeLow"]


GammaParamsFuture<-findGamma1(scale.init=c(2000,80000),shape.init = c(0.25,15),upp=future.pop.upp,low=future.pop.low)
GammaParamsFuture


futurepoprange<-seq(1000,200000,by=1000)
id.dist.future<-pgamma(futurepoprange,shape=GammaParamsFuture$shape,scale=GammaParamsFuture$scale,lower.tail = F)
id.df.future<-data.frame("Pop.range"=futurepoprange,"Probability"=id.dist.future)
yfuturepred<-pgamma(future.pop,shape=GammaParamsFuture$shape,scale=GammaParamsFuture$scale,lower.tail = F)

plot16<-ggplot(id.df.future, aes(x = Pop.range, y = Probability)) + 
  geom_point()+ 
  geom_errorbarh(aes(xmax=future.pop.upp,xmin=future.pop.low,y=yfuturepred,height=0.05))+
  geom_point(x = future.pop,y=yfuturepred,col="red")+  
  labs(x="N",y="Probability (population size >= N)")+
  annotate("text", x= 55000, y = 0.625,angle=0, label = paste0("Model prediction (90% CI) = ",round(future.pop,0)," (",round(future.pop.low,0)," - ",round(future.pop.upp,0),")"),size=4, hjust=0)
#I think this is just based on the BBS trends
ggsave(plot16, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot16_futurepopBBStrendgammadist.png", units="in", width=10, height=8)

# If using log-normal distribution
# mu<-log(future.pop)
# 
# phi<-0.73737
# qlnorm(p=c(0.025,0.975),meanlog = mu,sdlog=phi)
# 
# 
# futurepoprange<-seq(1000,200000,by=1000)
# id.dist.future<-plnorm(futurepoprange,meanlog=mu,sdlog=phi,lower.tail = F)
# id.df.future<-data.frame("Pop.range"=futurepoprange,"Probability"=id.dist.future)
# 
# ggplot(id.df.future, aes(x = Pop.range, y = Probability)) + geom_point()+ geom_vline(xintercept = future.pop,  color = "blue", size=0.8)+
#   labs(x="Population size")


# short trend #
# future.pop2<-newdf4[which(newdf4$year=="2040"),"psize"] ###
# 
# upp2<-newdf4[which(newdf4$year=="2040"),"psizeUpp"]
# low2<-newdf4[which(newdf4$year=="2040"),"psizeLow"]
# 
# mat2<-expand.grid(scale=runif(1000,min=1000,max=100000),shape=runif(1000,min=0.2,max=30))
# mat2[,3:4]<-t(apply(mat2,1,FUN = function(x){qgamma(p=c(0.025,0.975),shape=x[2],scale=x[1])}))
# mat2$distances<-pointDistance(p1=mat2[,3:4],p2=c(low2,upp2),lonlat = F)
# mat2[which.min(mat2$distances),]
# 
# low2
# upp2
# qgamma(p=c(0.025,0.975),shape = 15,scale=220000)
# 
# futurepoprange<-seq(1000,200000,by=1000)
# id.dist.future<-pgamma(futurepoprange,shape=2.705717,scale=18677.86,lower.tail = F)
# id.df.future<-data.frame("Pop.range"=futurepoprange,"Probability"=id.dist.future)



# Future conditions population size - LANDIS simulations ####

#1. Predictions for 2100 
bootstrap_predictions2100<-bootstrap_predictions2100[bootstrap_predictions2100$Year==2100,]
bootstrap_predictions2100$Sc_x_Tr<-paste0(bootstrap_predictions2100$scenario,"_",bootstrap_predictions2100$treatment)

getLandisPreds2100<-function(scenario){
  Sc_x_Tr<-scenario
  bootstrap_predictions2100<-bootstrap_predictions2100[bootstrap_predictions2100$Sc_x_Tr==Sc_x_Tr,]
  
  #filelist<-list.files("E:/CWS Wood Thrush Contract/CHID previous work Francisco/CHID regional NS BRT/Nova Scotia Landscape simulation results/Prediction raster/",pattern=scenario)
  preds<-rep(NA,5)
  # for(i in 1:length(filelist)){
  #   load(paste0("E:/CWS Wood Thrush Contract/CHID previous work Francisco/CHID regional NS BRT/Nova Scotia Landscape simulation results/Prediction raster/",filelist[i]))
  #   landispreds2100<-PredictBirdsp.l[[3]] # 3 is for 2100
  #   #Lionel: replaced PredictBirdsp.l[[6]] # 6 is for 2100
  #   landispreds2100<-landispreds2100*6.25  # Multiplying density values by 6.25 (hectars in a 250-250 pixel) to get abundance for each cell and overall population size
  #   preds[i]<-cellStats(landispreds2100,stat=sum,na.rm=T)
  # }
  preds.out<-bootstrap_predictions2100%>%
    summarize(mean=mean(Popsize),sd=sd(Popsize))#Popsize instead of preds
  #preds.out<-data.frame(mean=mean(preds),sd=sd(preds))
  
  return(preds.out)
  }

scenarios2100<-getLandisPreds2100("baseline_BudwormBaselineFire")
scenarios2100[2,]<-getLandisPreds2100("baseline_BudwormBaselineFireEBFMHarvest")
scenarios2100[3,]<-getLandisPreds2100("baseline_BudwormBaselineFireHighCPRSHarvest")
scenarios2100[4,]<-getLandisPreds2100("baseline_BudwormBaselineFireHighPartialHarvest")
scenarios2100[5,]<-getLandisPreds2100("baseline_BudwormBaselineFireLowCPRSHarvest")
scenarios2100[6,]<-getLandisPreds2100("baseline_BudwormBaselineFireLowPartialHarvest")

# scenarios2100[7,]<-getLandisPreds2100("RCP26_GrowthBudwormProjectedFire_")
# scenarios2100[8,]<-getLandisPreds2100("RCP26_GrowthBudwormProjectedFireEBFMHarvest_")
# scenarios2100[9,]<-getLandisPreds2100("RCP26_GrowthBudwormProjectedFireHighCPRSHarvest_")
# scenarios2100[10,]<-getLandisPreds2100("RCP26_GrowthBudwormProjectedFireHighPartialHarvest_")
# scenarios2100[11,]<-getLandisPreds2100("RCP26_GrowthBudwormProjectedFireLowCPRSHarvest_")
# scenarios2100[12,]<-getLandisPreds2100("RCP26_GrowthBudwormProjectedFireLowPartialHarvest_")

scenarios2100[7,]<-getLandisPreds2100("RCP45_GrowthBudwormProjectedFire")
scenarios2100[8,]<-getLandisPreds2100("RCP45_GrowthBudwormProjectedFireEBFMHarvest")
scenarios2100[9,]<-getLandisPreds2100("RCP45_GrowthBudwormProjectedFireHighCPRSHarvest")
scenarios2100[10,]<-getLandisPreds2100("RCP45_GrowthBudwormProjectedFireHighPartialHarvest")
scenarios2100[11,]<-getLandisPreds2100("RCP45_GrowthBudwormProjectedFireLowCPRSHarvest")
scenarios2100[12,]<-getLandisPreds2100("RCP45_GrowthBudwormProjectedFireLowPartialHarvest")

scenarios2100[13,]<-getLandisPreds2100("RCP85_GrowthBudwormProjectedFire")
scenarios2100[14,]<-getLandisPreds2100("RCP85_GrowthBudwormProjectedFireEBFMHarvest")
scenarios2100[15,]<-getLandisPreds2100("RCP85_GrowthBudwormProjectedFireHighCPRSHarvest")
scenarios2100[16,]<-getLandisPreds2100("RCP85_GrowthBudwormProjectedFireHighPartialHarvest")
scenarios2100[17,]<-getLandisPreds2100("RCP85_GrowthBudwormProjectedFireLowCPRSHarvest")
scenarios2100[18,]<-getLandisPreds2100("RCP85_GrowthBudwormProjectedFireLowPartialHarvest")

scenarios2100$scenario<-scenario.names
scenarios2100$Climate<-rep(c("Baseline","RCP45","RCP85"),each=6)#"RCP26",

scenarios2100
#CONTINUE - LANDIS BOOTSTRAP PREDICTIONS ####
#2. Load bootstrap predictions tables
bootpreds<-readRDS("2_BRT_outputs/GFsigma750m_new/bbs and landis trends/bootstrap_predictions2100.R")
str(bootpreds)
levels(bootpreds$scenario)
bootpreds<-bootpreds[!bootpreds$scenario=="RCP26",]#remove RCP26
str(bootpreds)
bootpreds$treatment<-as.factor(bootpreds$treatment)
bootpreds$Year<-as.factor(bootpreds$Year)
bootpreds$FireTreatment<-as.factor(bootpreds$FireTreatment)
bootpreds$HarvestTreatment<-as.factor(bootpreds$HarvestTreatment)
write.csv(bootpreds, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/bootpreds.csv")

#create trajectories.df to replace the rasters no longer available for getLandisTrajectories function below
trajectories.df<-bootpreds%>%
  group_by(scenario, HarvestTreatment, Year)%>% #HarvestTreatment instead of treatment
  summarize(Median=median(Popsize),
            mean=mean(Popsize),
            Stdev=sd(Popsize),
            Stderr=Stdev/sqrt(5),
            CI.05=mean(Popsize)-1.96*Stderr,
            CI.95=mean(Popsize)+1.96*Stderr,
            BCI.05=quantile(Popsize,0.05),
            BCI.95=quantile(Popsize,0.95))
write.csv(trajectories.df, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/NStrajectories.df.csv")

bootpreds<-bootpreds[bootpreds$Year==2100,]
bootpreds$scenarioname<-rep(scenario.names,each=5)
#bootpreds$scenarioname<-rep(rep(scenario.names,each=250),5)

#3. Quantify uncertainty from bootstrap predictions, for each scenario. 
#This is achieved by approximating the parameters of a gamma distribution 
#whose quantiles fit those of the bootstrap distribution
bootpreds2100<-subset(bootpreds,Year=="2100")
summary(bootpreds2100)
levels(bootpreds2100$treatment)

# each of the objects below, representing the different scenarios, has 250 (bootstrao samples) x 5 (simulation replicates) = 1250 population size estimates
baseline_BudwormBaselineFire_2100 <- bootpreds2100[which(bootpreds2100$treatment=="BudwormBaselineFire"),] 
baseline_BudwormBaselineFireEBFMHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="BudwormBaselineFireEBFMHarvest"),]
baseline_BudwormBaselineFireHighCPRSHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="BudwormBaselineFireHighCPRSHarvest"),]
baseline_BudwormBaselineFireHighPartialHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="BudwormBaselineFireHighPartialHarvest"),]
baseline_BudwormBaselineFireLowCPRSHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="BudwormBaselineFireLowCPRSHarvest"),]
baseline_BudwormBaselineFireLowPartialHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="BudwormBaselineFireLowPartialHarvest"),]

# RCP26_GrowthBudwormProjectedFire_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFire"&bootpreds2100$scenario=="RCP26"),]
# RCP26_GrowthBudwormProjectedFireEBFMHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFireEBFMHarvest"&bootpreds2100$scenario=="RCP26"),]
# RCP26_GrowthBudwormProjectedFireHighCPRSHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFireHighCPRSHarvest"&bootpreds2100$scenario=="RCP26"),]
# RCP26_GrowthBudwormProjectedFireHighPartialHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFireHighPartialHarvest"&bootpreds2100$scenario=="RCP26"),]
# RCP26_GrowthBudwormProjectedFireLowCPRSHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFireLowCPRSHarvest"&bootpreds2100$scenario=="RCP26"),]
# RCP26_GrowthBudwormProjectedFireLowPartialHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFireLowPartialHarvest"&bootpreds2100$scenario=="RCP26"),]

RCP45_GrowthBudwormProjectedFire_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFire"&bootpreds2100$scenario=="RCP45"),]
RCP45_GrowthBudwormProjectedFireEBFMHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFireEBFMHarvest"&bootpreds2100$scenario=="RCP45"),]
RCP45_GrowthBudwormProjectedFireHighCPRSHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFireHighCPRSHarvest"&bootpreds2100$scenario=="RCP45"),]
RCP45_GrowthBudwormProjectedFireHighPartialHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFireHighPartialHarvest"&bootpreds2100$scenario=="RCP45"),]
RCP45_GrowthBudwormProjectedFireLowCPRSHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFireLowCPRSHarvest"&bootpreds2100$scenario=="RCP45"),]
RCP45_GrowthBudwormProjectedFireLowPartialHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFireLowPartialHarvest"&bootpreds2100$scenario=="RCP45"),]

RCP85_GrowthBudwormProjectedFire_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFire"&bootpreds2100$scenario=="RCP85"),]
RCP85_GrowthBudwormProjectedFireEBFMHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFireEBFMHarvest"&bootpreds2100$scenario=="RCP85"),]
RCP85_GrowthBudwormProjectedFireHighCPRSHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFireHighCPRSHarvest"&bootpreds2100$scenario=="RCP85"),]
RCP85_GrowthBudwormProjectedFireHighPartialHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFireHighPartialHarvest"&bootpreds2100$scenario=="RCP85"),]
RCP85_GrowthBudwormProjectedFireLowCPRSHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFireLowCPRSHarvest"&bootpreds2100$scenario=="RCP85"),]
RCP85_GrowthBudwormProjectedFireLowPartialHarvest_2100 <- bootpreds2100[which(bootpreds2100$treatment=="GrowthBudwormProjectedFireLowPartialHarvest"&bootpreds2100$scenario=="RCP85"),]

boot_preds_2100_list<-list(baseline_BudwormBaselineFire_2100,
                           baseline_BudwormBaselineFireEBFMHarvest_2100,
                           baseline_BudwormBaselineFireHighCPRSHarvest_2100,
                           baseline_BudwormBaselineFireHighPartialHarvest_2100,
                           baseline_BudwormBaselineFireLowCPRSHarvest_2100,
                           baseline_BudwormBaselineFireLowPartialHarvest_2100,
                           # RCP26_GrowthBudwormProjectedFire_2100,
                           # RCP26_GrowthBudwormProjectedFireEBFMHarvest_2100,
                           # RCP26_GrowthBudwormProjectedFireHighCPRSHarvest_2100,
                           # RCP26_GrowthBudwormProjectedFireHighPartialHarvest_2100,
                           # RCP26_GrowthBudwormProjectedFireLowCPRSHarvest_2100,
                           # RCP26_GrowthBudwormProjectedFireLowPartialHarvest_2100,
                           RCP45_GrowthBudwormProjectedFire_2100,
                           RCP45_GrowthBudwormProjectedFireEBFMHarvest_2100,
                           RCP45_GrowthBudwormProjectedFireHighCPRSHarvest_2100,
                           RCP45_GrowthBudwormProjectedFireHighPartialHarvest_2100,
                           RCP45_GrowthBudwormProjectedFireLowCPRSHarvest_2100,
                           RCP45_GrowthBudwormProjectedFireLowPartialHarvest_2100,
                           RCP85_GrowthBudwormProjectedFire_2100,
                           RCP85_GrowthBudwormProjectedFireEBFMHarvest_2100,
                           RCP85_GrowthBudwormProjectedFireHighCPRSHarvest_2100,
                           RCP85_GrowthBudwormProjectedFireHighPartialHarvest_2100,
                           RCP85_GrowthBudwormProjectedFireLowCPRSHarvest_2100,
                           RCP85_GrowthBudwormProjectedFireLowPartialHarvest_2100) 

probsCI<-c(0.05,0.95) # can change these probabilities for more or less conservative intervals

boot_preds_2100_CIs<-matrix(unlist(lapply(boot_preds_2100_list,FUN=function(x){quantile(x$Popsize, probs=probsCI)})),18,2,byrow = T)
boot_preds_2100_CIs
#changed 24 to 18
scenarios2100$bootLower<-boot_preds_2100_CIs[,1]
scenarios2100$bootUpper<-boot_preds_2100_CIs[,2]
scenarios2100 

findGamma2<-function(x,scale.init,shape.init){
 low<-as.numeric(x[5])
 upp<-as.numeric(x[6])
 mat<-expand.grid(scale=runif(1000,min=scale.init[1],max=scale.init[2]),shape=runif(1000,min=shape.init[1],max=shape.init[2]))
 mat[,3:4]<-t(apply(mat,1,FUN = function(x){qgamma(p=c(0.025,0.975),shape=x[2],scale=x[1])}))
 mat$distances<-pointDistance(p1=mat[,3:4],p2=c(low,upp),lonlat = F)
 out1<-mat[which.min(mat$distances),]
 
 scale.init2<-unlist(c(out1[1]-(out1[1]*0.25),out1[1]+(out1[1]*0.25)))
 shape.init2<-unlist(c(out1[2]-(out1[2]*0.25),out1[2]+(out1[2]*0.25)))
 
 mat2<-expand.grid(scale=runif(1000,min=scale.init2[1],max=scale.init2[2]),shape=runif(1000,min=shape.init2[2],max=shape.init2[2]))
 mat2[,3:4]<-t(apply(mat2,1,FUN = function(x){qgamma(p=c(0.025,0.975),shape=x[2],scale=x[1])}))
 mat2$distances<-pointDistance(p1=mat2[,3:4],p2=c(low,upp),lonlat = F)
 
 mat3<-rbind(mat,mat2)
 mat3[which.min(mat3$distances),]
 }

parametersGamma2100<-apply(scenarios2100,MARGIN = 1,FUN=findGamma2,scale.init=c(20000,80000),shape.init = c(0.25,15))
parametersGamma2100<-as.data.frame(matrix(unlist(parametersGamma2100),ncol=5,nrow=18,byrow=T, dimnames=list(1:18,names(parametersGamma2100[[1]]))))
#changed from 24 to 18
parametersGamma2100$scenario<-scenario.names
parametersGamma2100
names(parametersGamma2100)[c(3,4)]<-c("lowerCL","upperCL")

# Scenario-specific future pop size probability plots ####

pop.prob.2100<-as.list(scenarios2100$scenario)
names(pop.prob.2100)<-scenarios2100$scenario

id.df.future.2100<-data.frame("Pop.range"=NA,"Probability"=NA,"scenario"=NA)
for(i in 1:length(pop.prob.2100)){
  futurepoprange<-seq(1000,350000,by=1000)
  id.dist.future.2100<-pgamma(futurepoprange,shape=parametersGamma2100$shape[i],scale=parametersGamma2100$scale[i],lower.tail = F)
  
  id.df.future.2100[(1:length(futurepoprange))+length(futurepoprange)*(i-1),]<-cbind(futurepoprange,id.dist.future.2100,names(pop.prob.2100)[i])
}

id.df.future.2100$Pop.range<-as.numeric(id.df.future.2100$Pop.range)
id.df.future.2100$Probability<-as.numeric(id.df.future.2100$Probability)
str(id.df.future.2100)

plot17<-ggplot(id.df.future.2100, aes(x = Pop.range, y = Probability,color=scenario)) +
  geom_point()+
  geom_vline(mapping=aes(xintercept = mean,color=scenario),data=scenarios2100, size=0.8,alpha=0.4)+
  labs(x="Population size")+
  annotate("text", x= 55000, y = 0.93,angle=0, label = paste0("Future population size predictions \n (mean = ",round(mean(scenarios2100$mean),0),")"),size=4, hjust=0)+
  #annotate("text", x= 150000, y = 0.93,angle=0, label = paste0("Scenario: ",scenarios2100$scenario[i]),size=4)+
  ylim(0,1)+
  scale_color_discrete(guide=guide_legend(ncol=1))+
  scale_x_continuous(labels = scales::comma)+
  labs(x="N",y="Probability (population size >= N)")
plot17
ggsave(plot17, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot17_pop.prob.2100.plot.png", units="in", width=10, height=8)


plot17B<-ggplot(id.df.future.2100, aes(x = Pop.range, y = Probability,color=scenario)) +
  geom_point()+
  geom_vline(mapping=aes(xintercept = mean,color=scenario),data=scenarios2100, size=0.8,alpha=0.4)+
  labs(x="Population size")+
  annotate("text", x= 55000, y = 0.93,angle=0, label = paste0("Future population size predictions \n (mean = ",round(mean(scenarios2100$mean),0),")"),size=4, hjust=0)+
  #annotate("text", x= 150000, y = 0.93,angle=0, label = paste0("Scenario: ",scenarios2100$scenario[i]),size=4)+
  ylim(0,1)+
  scale_color_discrete(guide=guide_legend(ncol=1))+
  scale_x_continuous(labels = scales::comma)+
  xlim(0,100000)+
  labs(x="N",y="Probability (population size >= N)")
plot17B
ggsave(plot17B, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot17B_pop.prob.2100.plot.png", units="in", width=10, height=8)

# getLandisTrajectory<-function(scenario){
#   filelist<-list.files("E:/CWS Wood Thrush Contract/CHID previous work Francisco/CHID regional NS BRT/Nova Scotia Landscape simulation results/Prediction raster/",pattern=scenario)
#   preds<-matrix(NA,5,5)#replaced from preds<-matrix(NA,11,5) in original script
#   for(i in 1:length(filelist)){
#     load(paste0("E:/CWS Wood Thrush Contract/CHID previous work Francisco/CHID regional NS BRT/Nova Scotia Landscape simulation results/Prediction raster/",filelist[i]))
#     preds[,i]<-unlist(lapply(PredictBirdsp.l,FUN=function(x){cellStats(x*6.25,stat=sum,na.rm=T)}))
#     #Error in preds[, i] <- unlist(lapply(PredictBirdsp.l, FUN = function(x) { : 
#     #number of items to replace is not a multiple of replacement length
#   }
#   preds.out<-data.frame(mean=apply(preds,1,mean),year=seq(2000,2200,by=50))#replaced by=20 with by=50
# 
#   return(preds.out)
# }
# 
# trajectories<-as.list(rep(NA,18))#replaced 24 with 18
# for(i in 1:length(scenario.names)){
#   trajectories[[i]]<-getLandisTrajectory(paste0(scenario.names,"_")[i])
# }
# trajectories
# 
# trajectories<-bind_rows(trajectories)
# trajectories$scenario<-rep(scenario.names,each=5)#Changed from 11 to 5
# 
# trajectories<-subset(trajectories,year>2010)
# trajectories<-subset(trajectories,year<2120)
# 
# traj_boot<-aggregate(bootpreds$Popsize,by=list(bootpreds$scenarioname,bootpreds$Year),FUN=quantile,probs=c(0.05,0.95))
# 
# traj_boot<-data.frame(scenario=traj_boot$Group.1,year=traj_boot$Group.2,lower=traj_boot$x[,1],upper=traj_boot$x[,2])
# traj_boot$year<-as.numeric(as.character(traj_boot$year))
# 
# trajectories.df<-data.frame(trajectories)
# write.csv(trajectories.df, file="trajectories.df.csv")

trajectories.df<-read.csv("2_BRT_outputs/GFsigma750m_new/bbs and landis trends/NStrajectories.df.csv", header=TRUE)

plot18<-ggplot(data=newdf2)+
  geom_ribbon(aes(x=year,ymin=psizeLow,ymax=psizeUpp),fill="blue",alpha=0.2)+
  geom_line(aes(x=year,y=psize),color="blue")+
  geom_vline(xintercept = 2019,  size=0.5,linetype="dashed")+
  geom_errorbarh(aes(xmax=2050,xmin=2018,y=126000,height=20000))+
  guides(fill = guide_legend(reverse=TRUE),color=guide_legend(reverse=TRUE))+
  labs(x = "Years", y="Population size (males)", fill="",color="")+
  #scale_y_continuous(labels = comma)+
  annotate("text", x= 2021, y = 400000,hjust=0, label = paste0("BRT model reference year (2007) \n", paste0("Estimate (90% CI) = ",round(popsize,0)," (",round(popsize.low,0)," - ",round(popsize.upp,0),")")),size=4)+
  annotate("text", x= 2021, y = 155000,hjust=0, label = ("Predictions with BBS long-term trend (2019): \n -3.09 (-4.47, -1.81)"),size=4)+
  geom_rug(data=yearsdata, aes(x=Year,y=Freq),length=unit(yearsdata$Freq/50000,"npc"),sides="b", alpha=0.5, position=jitter)+
  geom_errorbar(data=trajectories.df,aes(x=Year,ymin=BCI.05,ymax=BCI.95,color=scenario),position=position_dodge(width=3),width=20,alpha=0.5)+
  #geom_errorbar(data=traj_boot,aes(x=year,ymin=lower,ymax=upper,color=scenario),position=position_dodge(width=3),width=20,alpha=0.5)+
  geom_errorbarh(aes(xmax=2100,xmin=2020,y=68000,height=20000))+
  annotate("text", x= 2050, y = 80000,angle=0, label = "Predictions with LANDIS-II simulations",size=4, hjust=0)+
  geom_line(data=subset(trajectories.df,Year<2101),aes(x=Year,y=mean,color=scenario))+
  guides(col=guide_legend(ncol=1))+
  theme(legend.text=element_text(size=8))+
  annotate("text", x= 2100, y = 300000,angle=0, label = "Bootstrap 90%CI (2100)",size=4, hjust=1)
plot18
ggsave(plot18, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot18_longtermBBSandLandisTrajectories.2100.plot.png", units="in", width=10, height=8)


#6. Calculate future trend 
futuretrend<-function(datafuture,datacurrent=newdf2,baseyear=2019){
  years<-2100-baseyear
  
  N0<-datacurrent[which(datacurrent$year==baseyear),"psize"]
  lower<-datacurrent[which(datacurrent$year==baseyear),"psizeLow"]
  upper<-datacurrent[which(datacurrent$year==baseyear),"psizeUpp"]
  
  N1<-datafuture
  
  trend<-100*((N1/N0)^(1/years)-1)
  trendLow<-100*((N1/upper)^(1/years)-1)
  trendUpp<-100*((N1/lower)^(1/years)-1)
  
  return(data.frame(trend=trend,lowerCL=trendLow,upperCL=trendUpp))
}

## Estimates
futuretrendsSims<-futuretrend(datafuture = scenarios2100$mean)
futuretrendsSims$scenario<-as.factor(scenario.names)
futuretrendsSims

## bootstrap samples
boot_preds_2100_df<-rbind(baseline_BudwormBaselineFire_2100,
                           baseline_BudwormBaselineFireEBFMHarvest_2100,
                           baseline_BudwormBaselineFireHighCPRSHarvest_2100,
                           baseline_BudwormBaselineFireHighPartialHarvest_2100,
                           baseline_BudwormBaselineFireLowCPRSHarvest_2100,
                           baseline_BudwormBaselineFireLowPartialHarvest_2100,
                           # RCP26_GrowthBudwormProjectedFire_2100,
                           # RCP26_GrowthBudwormProjectedFireEBFMHarvest_2100,
                           # RCP26_GrowthBudwormProjectedFireHighCPRSHarvest_2100,
                           # RCP26_GrowthBudwormProjectedFireHighPartialHarvest_2100,
                           # RCP26_GrowthBudwormProjectedFireLowCPRSHarvest_2100,
                           # RCP26_GrowthBudwormProjectedFireLowPartialHarvest_2100,
                           RCP45_GrowthBudwormProjectedFire_2100,
                           RCP45_GrowthBudwormProjectedFireEBFMHarvest_2100,
                           RCP45_GrowthBudwormProjectedFireHighCPRSHarvest_2100,
                           RCP45_GrowthBudwormProjectedFireHighPartialHarvest_2100,
                           RCP45_GrowthBudwormProjectedFireLowCPRSHarvest_2100,
                           RCP45_GrowthBudwormProjectedFireLowPartialHarvest_2100,
                           RCP85_GrowthBudwormProjectedFire_2100,
                           RCP85_GrowthBudwormProjectedFireEBFMHarvest_2100,
                           RCP85_GrowthBudwormProjectedFireHighCPRSHarvest_2100,
                           RCP85_GrowthBudwormProjectedFireHighPartialHarvest_2100,
                           RCP85_GrowthBudwormProjectedFireLowCPRSHarvest_2100,
                           RCP85_GrowthBudwormProjectedFireLowPartialHarvest_2100) 





fut.trend.df<-futuretrend(datafuture=boot_preds_2100_df$Popsize)
fut.trend.df

fut.trend.df$scenario<-boot_preds_2100_df$scenarioname#as.factor(rep(scenario.names,each=1250))

fut.trends.plot<-ggplot(fut.trend.df,aes(x=scenario,y=trend))+geom_boxplot()+coord_flip()+geom_hline(yintercept=0, colour="blue")+geom_point(data=futuretrendsSims,aes(x=scenario,y=trend),shape=3,color="red")
fut.trends.plot
ggsave(fut.trends.plot, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot19_futureLandisTrajectories.2100.horizbarplot.png", units="in", width=10, height=8)


futuretrend2<-function(scenarioindex,datafuture=scenarios2100,datacurrent=newdf2,baseyear=2019){
  years<-2100-baseyear

  N0<-datacurrent[which(datacurrent$year==baseyear),"psize"]
  lower<-datacurrent[which(datacurrent$year==baseyear),"psizeLow"]
  upper<-datacurrent[which(datacurrent$year==baseyear),"psizeUpp"]

  N1<-datafuture[scenarioindex,"mean"]
  N1low<-datafuture[scenarioindex,"bootLower"]
  N1upp<-datafuture[scenarioindex,"bootUpper"]

  trend<-100*((N1/N0)^(1/years)-1)
  trendLow<-100*((N1low/upper)^(1/years)-1)
  trendUpp<-100*((N1upp/lower)^(1/years)-1)

  return(data.frame(trend=trend,lowerCL=trendLow,upperCL=trendUpp))
}


fut.trend.df2<-as.data.frame(matrix(unlist(lapply(1:18,FUN=futuretrend2)),ncol=3,nrow=18,byrow=T, dimnames=list(1:18,c("trend","lowerCL","upperCL"))))
#replaced 24 with 18
fut.trend.df2$scenario<-as.factor(scenario.names)
fut.trend.df2

write.csv(fut.trend.df2,"2_BRT_outputs/GFsigma750m_new/bbs and landis trends/future_trends.csv")

fut.trend.df2$maxmin<-3
fut.trend.df2$maxmin[(which.min(fut.trend.df2$trend))]<-1
fut.trend.df2$maxmin[(which.max(fut.trend.df2$trend))]<-2


fut.trends.plot2<-ggplot(fut.trend.df2,aes(x=trend,y=scenario,color=factor(maxmin)))+
  geom_point()+xlim(-4,4)+
  geom_errorbarh(data=fut.trend.df2,aes(xmax=upperCL,xmin=lowerCL,color=factor(maxmin)))+
  labs(x="Future trend (2000-2100)",y="Scenario")+
  scale_color_manual(labels=c("Minimum","Maximum","Others"),values=c("Red","Blue", "Black")) +
  theme(legend.title = element_blank())
fut.trends.plot2
ggsave(fut.trends.plot2, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot20_futureLandisTrajectories.2100.horizdotwhiskerplot.png", units="in", width=10, height=8)


# Estimate distribution function for future trend ####
# As we can see from plot above, CL are also not symetrical with the mean
# So need to use a distribution that can allow asymetrical shapes AND negative values
# enter the Exponentially Modified Gaussian (EMG) Distribution

library(emg)

findEMG<-function(x,mu.init,sigma.init,lambda.init,N=10){
  low<-as.numeric(x[2])
  upp<-as.numeric(x[3])
  mat<-expand.grid(mu=runif(N,min=min(mu.init),max=max(mu.init)),sigma=runif(N,min=sigma.init[1],max=sigma.init[2]),lambda=runif(N,min=lambda.init[1],max=lambda.init[2]))
  mat[,4:5]<-t(apply(mat,1,FUN = function(x){qemg(p=c(0.05,0.95),mu=x[1],sigma=x[2],lambda=x[3])}))
  mat$distances<-pointDistance(p1=mat[,4:5],p2=c(low,upp),lonlat = F)
  out1<-mat[which.min(mat$distances),]
  
  mu.init2<-unlist(c(out1[1]-(out1[1]*0.25),out1[1]+(out1[1]*0.25)))
  sigma.init2<-unlist(c(out1[2]-(out1[2]*0.25),out1[2]+(out1[2]*0.25)))
  lambda.init2<-unlist(c(out1[3]-(out1[3]*0.25),out1[3]+(out1[3]*0.25)))
  
  mat2<-expand.grid(mu=runif(N,min=min(mu.init2),max=max(mu.init2)),sigma=runif(N,min=min(sigma.init2),max=max(sigma.init2)),lambda=runif(N,min=lambda.init2[1],max=lambda.init2[2]))
  mat2[,4:5]<-t(apply(mat,1,FUN = function(x){qemg(p=c(0.05,0.95),mu=x[1],sigma=x[2],lambda=x[3])}))
  mat2$distances<-pointDistance(p1=mat2[,4:5],p2=c(low,upp),lonlat = F)
  
  mat3<-rbind(mat,mat2)
  colnames(mat3)[4:5]<-c("lowerCL_0.5","upperCL_0.95")
  return(mat3[which.min(mat3$distances),])
}

library(pbapply)
EMGparams2100<-pbapply(fut.trend.df2, MARGIN=1, FUN=findEMG,mu.init=c(-2,2),sigma.init=c(0.5,5),lambda.init=c(0.1,1),N=25)
EMGparams2100<-as.data.frame(matrix(unlist(EMGparams2100),ncol=6,nrow=18,byrow=T, dimnames=list(1:18,names(EMGparams2100[[1]]))))
#replaced 24 with 18
save(EMGparams2100, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/EMGparams2100.RData")

#8. Generate plot for future trend distribution function
# Assuming EMG distribution
id.df.fut.trend.2100<-data.frame("Trend"=NA,"Probability"=NA,"scenario"=NA)
for(i in 1:length(pop.prob.2100)){
  fut.trend.range<-seq(-4,5,length.out=350)
  id.dist.fut.trend.2100<-pemg(fut.trend.range,mu=EMGparams2100$mu[i],sigma=EMGparams2100$sigma[i],lambda=EMGparams2100$lambda[i],lower.tail = F)

  id.df.fut.trend.2100[(1:length(fut.trend.range))+length(fut.trend.range)*(i-1),]<-cbind(fut.trend.range,id.dist.fut.trend.2100,names(pop.prob.2100)[i])
}


id.df.fut.trend.2100$Trend<-as.numeric(id.df.fut.trend.2100$Trend)
id.df.fut.trend.2100$Probability<-as.numeric(id.df.fut.trend.2100$Probability)
str(id.df.fut.trend.2100)
#'data.frame':	6300 obs. of  3 variables:
#$ Trend      : num  -4 -3.97 -3.95 -3.92 -3.9 ...
#$ Probability: num  1 1 1 1 1 ...
#$ scenario   : chr  "baseline_BudwormBaselineFire" "baseline_BudwormBaselineFire" "baseline_BudwormBaselineFire" "baseline_BudwormBaselineFire" ...
#Probability=probability trend value >= to value in $Trend
write.csv(id.df.fut.trend.2100, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/ProbabilityOfPositiveTrend.csv")

trend.prob.2100.plot<-ggplot(id.df.fut.trend.2100, aes(x = Trend, y = Probability,color=scenario)) +
  geom_point(alpha=0.6)+
  geom_vline(mapping=aes(xintercept = trend,color=scenario),data=fut.trend.df2, size=0.8,alpha=0.4)+
  #annotate("text", x= 55000, y = 0.93,angle=0, label = paste0("Future trend predictions \n (mean = ",round(mean(fut.trend.df2$trend),0),")"),size=4, hjust=0)+
  #annotate("text", x= 150000, y = 0.93,angle=0, label = paste0("Scenario: ",scenarios2100$scenario[i]),size=4)+
  xlim(-4,5)+
  ylim(0,1)+
  scale_color_discrete(guide=guide_legend(ncol=1))+
  #scale_x_continuous(labels = scales::comma)+
  labs(x="T",y="Probability (Trend >= T)")
trend.prob.2100.plot
ggsave(trend.prob.2100.plot, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot21_futureLandisTrendprobabilities.2100.png", units="in", width=10, height=8)
#Once we get this plot (without RCP 26), need to calculate area
#under each curve >=0
#https://stackoverflow.com/questions/40851328/compute-area-under-density-estimation-curve-i-e-probability

# Assuming Normal distribution

# id.df.fut.trend.2100<-data.frame("Trend"=NA,"Probability"=NA,"scenario"=NA)
# for(i in 1:length(pop.prob.2100)){
#   fut.trend.range<-seq(-4,5,length.out=350)
#   #id.dist.fut.trend.2100<-pemg(fut.trend.range,mu=EMGparams2100$mu[i],sigma=EMGparams2100$sigma[i],lambda=EMGparams2100$lambda[i],lower.tail = F)
#   id.dist.fut.trend.2100<-pnorm(fut.trend.range,mean=0,sd=1,lower.tail=F) # some random p values to test the loop
#   id.df.fut.trend.2100[(1:length(fut.trend.range))+length(fut.trend.range)*(i-1),]<-cbind(fut.trend.range,id.dist.fut.trend.2100,names(pop.prob.2100)[i])
# }
# 
# id.df.fut.trend.2100$Trend<-as.numeric(id.df.fut.trend.2100$Trend)
# id.df.fut.trend.2100$Probability<-as.numeric(id.df.fut.trend.2100$Probability)
# str(id.df.fut.trend.2100)
# 
# trend.prob.2100.plot<-ggplot(id.df.fut.trend.2100, aes(x = Trend, y = Probability,color=scenario)) +
#   geom_point(alpha=0.6)+
#   geom_vline(mapping=aes(xintercept = trend,color=scenario),data=fut.trend.df2, size=0.8,alpha=0.4)+
#   #annotate("text", x= 55000, y = 0.93,angle=0, label = paste0("Future trend predictions \n (mean = ",round(mean(fut.trend.df2$trend),0),")"),size=4, hjust=0)+
#   #annotate("text", x= 150000, y = 0.93,angle=0, label = paste0("Scenario: ",scenarios2100$scenario[i]),size=4)+
#   xlim(-4,5)+
#   ylim(0,1)+
#   scale_color_discrete(guide=guide_legend(ncol=1))+
#   #scale_x_continuous(labels = scales::comma)+
#   labs(x="T",y="Probability (Trend >= T)")
# trend.prob.2100.plot


