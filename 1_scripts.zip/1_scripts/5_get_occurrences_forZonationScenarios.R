#Get BRT output required for Zonation scenarios
memory.limit(size=56000)
load("0_data/BRT inputs/outputs.RData")
#loads the BRTs
library(ggplot2)
library(gbm)
library(dplyr)
library(tidyr)
library(raster)
library(maptools)
library(ncdf4)
library(rasterVis)
library(RColorBrewer)
library(zoo)
library(gridExtra)
#The purpose of this script is to show how to obtain
#point counts from the boosted regression trees for Canada
#Warbler in the Al-Pac FMA in northeastern Alberta. The
#point counts along with rasters from the previous script will 
#serve as some of the inputs for Zonation scenarios. 

#We are specifically interested in three items from the BRTs. 
#First, we need a raster of current mean predicted density from 248 BRT
#sample runs, along with a raster of the uncertainty (standard
#deviation) in those estimates for each 250-m pixel.
#We also extracted the locations of known Canada Warbler
#occurrences, with the measured abundance at each location.
#These locations will increase the weight and prioritization
#of those locations for conservation or special management.

#Get Current Mean and SD Density Rasters from "3_getLandisandBBStrajectories" script

#rast2 has been saved as "PresentPredictedDensity_mean" to each Zonation project
#SDpreds has been saved as "PresentPredictedDensity_SD" to each Zonation project

#Get Future Mean and SD Rasters from "4_get_rasters_for Zonation" script

#Once we have the necessary raster inputs, we set up a
#Zonation scenario outside of R and ran it. We then
#process some of the Zonation output inside R to generate
#plots the way we like.

meanpred<-raster("0_data/1_processed/Rasters for Zonation/PresentPredictedDensity_mean.tif")
SDpred<-raster("0_data/1_processed/Rasters for Zonation/PresentPredictedDensity_SD.tif")


#The rasters showing present mean and SD need to be cropped to the Landis outputs
NSlandis<-raster("0_data/Rasters for Zonation/ZonationMean_CAWA_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest.tif")
meanpred.crop <- crop(meanpred, NSlandis, snap="out")
meanpred.res<-resample(meanpred.crop, NSlandis, method="bilinear")
meanpred.NSlandis <- mask(x=meanpred.res, mask=NSlandis)
#density 0 - 0.2773 males or pairs/ha
writeRaster(meanpred.NSlandis, filename="0_data/Rasters for Zonation/PresentPredictedDensity_mean.tif", format="GTiff",overwrite=TRUE)

SDpred.crop <- crop(SDpred, NSlandis, snap="out")
SDpred.res<-resample(SDpred.crop, NSlandis, method="bilinear")
SDpred.NSlandis <- mask(x=SDpred.res, mask=NSlandis)
writeRaster(SDpred.NSlandis, filename="0_data/Rasters for Zonation/PresentPredictedDensity_SD.tif", format="GTiff",overwrite=TRUE)

#Now get CAWA point locations used in BRTs to create text file "SSI_CAWA_CH_NS"
SSI_CAWA_CH_NS<-datcombo[,c("X","Y","ABUND")]
str(SSI_CAWA_CH_NS)#15059
SSI_CAWA_CH_NS<-SSI_CAWA_CH_NS[SSI_CAWA_CH_NS$ABUND>0,]
str(SSI_CAWA_CH_NS)#193
#Now get rid of the points outside the Landis scenarios in Nova Scotia
extent(NSlandis)
#class      : Extent 
#xmin       : 2300250 
#xmax       : 2628750 
#ymin       : 6679500 
#ymax       : 7069000  
write.csv(SSI_CAWA_CH_NS, file="0_data/Rasters for Zonation/SSI_CAWA_CH_NS.csv")
#strip header from this file, add a fourth column of all zeros, then save as text file
#remove CAWA occurrences outside of Nova Scotia Landis II extent

