library(raster)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(blockCV)
library(sp)
library(dismo)
library(ggplot2)

# A function that fits the BRT model ('gbm.step' from dismo package) on pre-defined folds, and saves outputs ####
brt_blocks <- function(data = datcombo, pred.stack = pred_abs_2011, seed = 1222, pred.variables ,output.folder, blocks=NULL, keep.out = TRUE, tc=3,lr=0.001,bf=0.5, save.points.shp=FALSE){ 
  # Arguments for this function
  ## data: data.frame object containing data for model fitting
  ## pred.stack: the raster stack/brick used as prediction dataset
  ## pred.variables: a character vector giving the names of predictor variables that will be included in BRT models
  ## blocks: object resulting from 'spatialBlocks' function that contains classification of sample points into folds
  ## output.folder: path to output folder (if folder does not exist it is created)
  ## keep.out: logical, whether to keep the output in the workspace. both blocks object and the brt output are automatically saved in the output folder regardless
  ## tc: BRT tree complexity
  ## lr: BRT learning rate
  ## bf: BRT bag fraction
  ## save.points.shp: logical, whether to save survey points as a shapefile in output folder
  
  # fit BRT models using pre-determined folds for CV
  if (is.null(blocks)){
    folds<-NULL
    n.folds<-10
  }
  
  else {
    folds<-blocks$foldID
    n.folds<-blocks$k
  }
  
  x1 <-
    try(brt <-
          gbm.step(
            datcombo,
            gbm.y = "ABUND",
            gbm.x = pred.variables,
            fold.vector = folds,
            n.folds = n.folds,
            family = "poisson",
            tree.complexity = tc,
            learning.rate = lr,
            bag.fraction = bf,
            offset = datcombo$logoffset,
            site.weights = datcombo$wt,
            keep.fold.models = T,
            keep.fold.fit = T
          ))
  
  if(class(x1)=="NULL"){#retry models that didn't converge with smaller learning rate
    x1 <-
      try(brt <-
            gbm.step(
              datcombo,
              gbm.y = "ABUND",
              gbm.x = pred.variables,
              fold.vector = folds,
              n.folds = n.folds,
              family = "poisson",
              tree.complexity = tc,
              learning.rate = lr/10,
              bag.fraction = bf,
              offset = datcombo$logoffset,
              site.weights = datcombo$wt,
              keep.fold.models = T,
              keep.fold.fit = T
            ))
  }
  
  if(class(x1)=="NULL"){#retry models that didn't converge with smaller learning rate
    x1 <-
      try(brt <-
            gbm.step(
              datcombo,
              gbm.y = "ABUND",
              gbm.x = pred.variables,
              fold.vector = folds,
              n.folds = n.folds,
              family = "poisson",
              tree.complexity = tc,
              learning.rate = lr/100,
              bag.fraction = bf,
              offset = datcombo$logoffset,
              site.weights = datcombo$wt,
              keep.fold.models = T,
              keep.fold.fit = T
            ))
  }
  
  if(class(x1)=="NULL"){
    stop("Restart model with even smaller learning rate, or other predictors!")
  }
  
  # Define/create folders for storing outputs
  if (class(x1) != "try-error") {
    z <- output.folder
    
    if (file.exists(z) == FALSE) {
      dir.create(z)
    }
    
    if (is.null(blocks)){
      save(brt, file = paste(z, speclist[j], "brtAB.R", sep = ""))
    }
    
    else {
      save(blocks, file = paste(z, speclist[j], "blocks.R", sep = ""))
      save(brt, file = paste(z, speclist[j], "brtAB.R", sep = ""))
    }  
    
    
    ## Model evaluation
    varimp <- as.data.frame(brt$contributions)
    write.csv(varimp, file = paste(z, speclist[j], "varimp.csv", sep = ""))
    cvstats <- t(as.data.frame(brt$cv.statistics))
    write.csv(cvstats, file = paste(z, speclist[j], "cvstats.csv", sep =
                                      ""))
    pdf(paste(z, speclist[j], "_plot.pdf", sep = ""))
    gbm.plot(
      brt,
      n.plots = length(pred.variables),
      smooth = TRUE,
      plot.layout = c(3, 3),
      common.scale = T
    )
    dev.off()
    pdf(paste(z, speclist[j], "_plot.var-scale.pdf", sep = ""))
    gbm.plot(
      brt,
      n.plots = length(pred.variables),
      smooth = TRUE,
      plot.layout = c(3, 3),
      common.scale = F,
      write.title = F
    )
    dev.off()
    
    
    ## Model prediction
    
    rast <-
      predict(pred.stack,
              brt,
              type = "response",
              n.trees = brt$n.trees)
    writeRaster(
      rast,
      filename = paste(z, speclist[j], "_pred1km", sep = ""),
      format = "GTiff",
      overwrite = TRUE
    )
    
    data_sp <-SpatialPointsDataFrame(coords = data[,c("X","Y")], data = data, proj4string = LCC)
    png(paste(z, speclist[j], "_pred1km.png", sep = ""))
    plot(rast, zlim = c(0, 1))
    points(data_sp$X, data_sp$Y, cex = 0.05)
    dev.off()
    
    if(save.points.shp==T){
      writeOGR(
        data_sp,
        dsn = paste(z, "surveypoints.shp", sep = ""),
        layer = "data_sp",
        driver = "ESRI Shapefile"
      )
    }
    
    if(keep.out==T) {return(brt)}
  }
}

#load data and prepare objects ####
load("0_data/1_processed/data_pack.RData")
pred_abs_2011<-brick("0_data/1_processed/prediction dataset/abs2011_250m.grd")

j<-which(speclist=="CAWA") 

specoff <- filter(offcombo, SPECIES==as.character(speclist[j]))
specoff <- distinct(specoff)

specdat2001 <- filter(NSPC2001, SPECIES == as.character(speclist[j]))
specdat2001x <- aggregate(specdat2001$ABUND,by=list("PKEY"=specdat2001$PKEY,"SS"=specdat2001$SS), FUN=sum)
names(specdat2001x)[3] <- "ABUND"
dat1 <- right_join(specdat2001x,survey2001[,1:3],by=c("SS","PKEY")) #n=31864
dat1$SPECIES <- as.character(speclist[j])
dat1$ABUND <- as.integer(ifelse(is.na(dat1$ABUND),0,dat1$ABUND)) 
s2001 <- left_join(dat1,specoff, by=c("SPECIES","PKEY"))
d2001 <- left_join(s2001, dat2001, by=c("SS")) 

specdat2011 <- filter(NSPC2011, SPECIES == as.character(speclist[j]))
specdat2011x <- aggregate(specdat2011$ABUND,by=list("PKEY"=specdat2011$PKEY,"SS"=specdat2011$SS), FUN=sum)
names(specdat2011x)[3] <- "ABUND"  
dat2 <- right_join(specdat2011x,survey2011[,1:3],by=c("SS","PKEY"))
dat2$SPECIES <- as.character(speclist[j])
dat2$ABUND <- as.integer(ifelse(is.na(dat2$ABUND),0,dat2$ABUND)) 
s2011 <- left_join(dat2,specoff, by=c("SPECIES","PKEY"))
d2011 <- left_join(s2011, dat2011, by=c("SS")) 


datcombo <- rbind(d2001,d2011)
#There are a lot of NA values
datcombo[is.na(datcombo)] <- 0

#convert water table covariate to factor (the 5 levels are 1: 0-0.10m; 2: 0.11-0.50m; 30.51-2m; 4: 2.01-10m; 5: >10m)
datcombo$wtbl250 <- as.factor(datcombo$wtbl250)
datcombo$wtbl250_modal3x3 <- as.factor(datcombo$wtbl250_modal3x3)
datcombo$wtbl250_modal5x5 <- as.factor(datcombo$wtbl250_modal5x5)

#convert water covariate at cell level to factor. (0: no water; 1: water)
datcombo$watNNS <- as.factor(datcombo$watNNS)

rm(list=setdiff(ls(),c("datcombo","pred_abs_2011","w","LCC","speclist","randomCV_brt","j","brt_blocks")))
gc()

# create a column converting abundance to occupancy
datcombo$OCCU <- 0 
datcombo$OCCU[which(datcombo$ABUND > 0)] <- 1

# convert data into SpatialPointDataFrame class
datcombo_sp <-SpatialPointsDataFrame(coords = datcombo[,c("X","Y")], data = datcombo, proj4string = LCC)


# Full model ####
# list variables for full model
pred.variables<-c( 
  "Species_Abie_Bal_v1",#
  "Species_Abie_Bal_v1_Gauss250",#
  "Species_Abie_Bal_v1_Gauss750",#
  "Species_Acer_Sah_v1",#
  "Species_Acer_Sah_v1_Gauss250",#
  "Species_Acer_Sah_v1_Gauss750",#
  "Species_Acer_Rub_v1",#
  "Species_Acer_Rub_v1_Gauss250",#
  "Species_Acer_Rub_v1_Gauss750",#
  "Species_Acer_Spi_v1",#
  "Species_Acer_Spi_v1_Gauss250",#
  "Species_Acer_Spi_v1_Gauss750",#
  "Species_Betu_All_v1",#
  "Species_Betu_All_v1_Gauss250",#
  "Species_Betu_All_v1_Gauss750",#
  "Species_Betu_Pap_v1",#
  "Species_Betu_Pap_v1_Gauss250",#
  "Species_Betu_Pap_v1_Gauss750",#
  "Species_Fagu_Gra_v1",#
  "Species_Fagu_Gra_v1_Gauss250",#
  "Species_Fagu_Gra_v1_Gauss750",#
  "Species_Frax_Ame_v1",#
  "Species_Frax_Ame_v1_Gauss250",#
  "Species_Frax_Ame_v1_Gauss750",#
  "Species_Lari_Lar_v1",#
  "Species_Lari_Lar_v1_Gauss250",#
  "Species_Lari_Lar_v1_Gauss750",#
  "Species_Pice_Gla_v1",#
  "Species_Pice_Gla_v1_Gauss250",#
  "Species_Pice_Gla_v1_Gauss750",#
  "Species_Pice_Rub_v1",#
  "Species_Pice_Rub_v1_Gauss250",#
  "Species_Pice_Rub_v1_Gauss750",#
  "Species_Pice_Mar_v1",#
  "Species_Pice_Mar_v1_Gauss250",#
  "Species_Pice_Mar_v1_Gauss750",#
  "Species_Pinu_Ban_v1",#
  "Species_Pinu_Ban_v1_Gauss250",#
  "Species_Pinu_Ban_v1_Gauss750",#
  "Species_Pinu_Res_v1",#
  "Species_Pinu_Res_v1_Gauss250",#
  "Species_Pinu_Res_v1_Gauss750",#
  "Species_Pinu_Str_v1",#
  "Species_Pinu_Str_v1_Gauss250",#
  "Species_Pinu_Str_v1_Gauss750",#
  "Species_Popu_Bal_v1",#
  "Species_Popu_Bal_v1_Gauss250",#
  "Species_Popu_Bal_v1_Gauss750",#
   "Species_Quer_Rub_v1",#
  "Species_Quer_Rub_v1_Gauss250",#
  "Species_Quer_Rub_v1_Gauss750",#
   "Species_Tsug_Can_v1",#
  "Species_Tsug_Can_v1_Gauss250",#
  "Species_Tsug_Can_v1_Gauss750",#
  "Structure_Biomass_TotalLiveAboveGround_v1",
  "Structure_Biomass_TotalLiveAboveGround_v1_Gauss250",
  "Structure_Biomass_TotalLiveAboveGround_v1_Gauss750",
  "Structure_Stand_Age_v1",
  "Structure_Stand_Age_v1_Gauss250",
  "Structure_Stand_Age_v1_Gauss750",
  "wtbl250",
  "wtbl250_modal3x3",
  "wtbl250_modal5x5",
  "CTI250",
  "CTI250_Gauss250",
  "CTI250_Gauss750",
  "roadsNNS",
  "roadsNNS_Gauss250",
  "roadsNNS_Gauss750",
  "urbagNNS",
  "urbagNNS_Gauss250",
  "urbagNNS_Gauss750",
  "watNNS",
  "watNNS_Gauss250",
  "watNNS_Gauss750",
  "ARU"
)
  
pred_abs_2011<- brick("0_data/1_processed/prediction dataset/abs2011_250m.grd")
#needs to be reloaded into R despite being listed in data_pack

# create object storing the indices of predictor layers (from the prediction dataset) for the autocorrelation assessment that will inform block size. Only include continuous numeric variables here. Can use indexing "[-c(x:y)] to exclude them (e.g. exclude climate variables, HF, etc).
ind <- which(names(pred_abs_2011) %in% pred.variables[-c(61:63,73)])
  
# Calculate autocorrelation range
start_time <- Sys.time()
sp.auto.arr1 <- spatialAutoRange(pred_abs_2011[[ind]])
end_time <- Sys.time()
end_time - start_time#Time difference of 5.836822 mins

# Use spatial blocks to separate train and test folds
start_time <- Sys.time()
set.seed(123)
sp_block_full <-  spatialBlock(
  speciesData = datcombo_sp,
  species = "OCCU",
  rasterLayer = pred_abs_2011[[1]],
  iteration = 250,
  theRange = sp.auto.arr1$range,
  selection = "random",
  maskBySpecies = FALSE,
  k=5
)
end_time <- Sys.time()
end_time - start_time#Time difference of 4.158599 mins

start_time<-Sys.time()
brt1<- brt_blocks(data=datcombo,pred.variables = pred.variables, lr=0.01,tc=3, output.folder = "2_BRT_outputs/full_model_new/test run/", blocks=sp_block_full, save.points.shp = TRUE)  
end_time<-Sys.time()
end_time-start_time

save(sp.auto.arr1, sp_block_full, file="2_BRT_outputs/full_model_new/test run/spautoarr1andblocks.RData")
save(brt1, file="2_BRT_outputs/full_model_new/test run/brt1.RData")

# Simplified model (selecting most influential scales) ####
# Note: scale selected for a particular variable was based on
# relative influence of that scale in the full BRT model during 
# testing on October 20, 2021.
pred.variables2<-c( 
  #"Species_Abie_Bal_v1",#
  #"Species_Abie_Bal_v1_Gauss250",#
  "Species_Abie_Bal_v1_Gauss750",#
  "Species_Acer_Sah_v1",#
  #"Species_Acer_Sah_v1_Gauss250",#
  #"Species_Acer_Sah_v1_Gauss750",#
  "Species_Acer_Rub_v1",#
  #"Species_Acer_Rub_v1_Gauss250",#
  #"Species_Acer_Rub_v1_Gauss750",#
  #"Species_Acer_Spi_v1",#
  #"Species_Acer_Spi_v1_Gauss250",#
  "Species_Acer_Spi_v1_Gauss750",#
  "Species_Betu_All_v1",#
  #"Species_Betu_All_v1_Gauss250",#
  #"Species_Betu_All_v1_Gauss750",#
  #"Species_Betu_Pap_v1",#
  "Species_Betu_Pap_v1_Gauss250",#
  #"Species_Betu_Pap_v1_Gauss750",#
  #"Species_Fagu_Gra_v1",#
  "Species_Fagu_Gra_v1_Gauss250",#
  #"Species_Fagu_Gra_v1_Gauss750",#
  #"Species_Frax_Ame_v1",#
  "Species_Frax_Ame_v1_Gauss250",#
  #"Species_Frax_Ame_v1_Gauss750",#
  #"Species_Lari_Lar_v1",#
  #"Species_Lari_Lar_v1_Gauss250",#
  "Species_Lari_Lar_v1_Gauss750",#
  "Species_Pice_Gla_v1",#
  #"Species_Pice_Gla_v1_Gauss250",#
  #"Species_Pice_Gla_v1_Gauss750",#
  #"Species_Pice_Rub_v1",#
  "Species_Pice_Rub_v1_Gauss250",#
  #"Species_Pice_Rub_v1_Gauss750",#
  #"Species_Pice_Mar_v1",#
  #"Species_Pice_Mar_v1_Gauss250",#
  "Species_Pice_Mar_v1_Gauss750",#
  #"Species_Pinu_Ban_v1",#
  #"Species_Pinu_Ban_v1_Gauss250",#
  "Species_Pinu_Ban_v1_Gauss750",#
  "Species_Pinu_Res_v1",#
  #"Species_Pinu_Res_v1_Gauss250",#
  #"Species_Pinu_Res_v1_Gauss750",#
  #"Species_Pinu_Str_v1",#
  #"Species_Pinu_Str_v1_Gauss250",#
  "Species_Pinu_Str_v1_Gauss750",#
  "Species_Popu_Bal_v1",#
  #"Species_Popu_Bal_v1_Gauss250",#
  #"Species_Popu_Bal_v1_Gauss750",#
  #"Species_Quer_Rub_v1",#
  #"Species_Quer_Rub_v1_Gauss250",#
  "Species_Quer_Rub_v1_Gauss750",#
  #"Species_Tsug_Can_v1",#
  #"Species_Tsug_Can_v1_Gauss250",#
  "Species_Tsug_Can_v1_Gauss750",#
  #"Structure_Biomass_TotalLiveAboveGround_v1",
  "Structure_Biomass_TotalLiveAboveGround_v1_Gauss250",
  #"Structure_Biomass_TotalLiveAboveGround_v1_Gauss750",
  #"Structure_Stand_Age_v1",
  "Structure_Stand_Age_v1_Gauss250",
  #"Structure_Stand_Age_v1_Gauss750",
  "wtbl250",
  #"wtbl250_modal3x3",
  #"wtbl250_modal5x5",
  #"CTI250",
  "CTI250_Gauss250",
  #"CTI250_Gauss750",
  "roadsNNS",
  #"roadsNNS_Gauss250",
  #"roadsNNS_Gauss750",
  #"urbagNNS",
  #"urbagNNS_Gauss250",
  "urbagNNS_Gauss750",
  #"watNNS",
  "watNNS_Gauss250",
  #,"watNNS_Gauss750",
  "ARU"
)

pred_abs_2011<- brick("0_data/1_processed/prediction dataset/abs2011_250m.grd")
#needs to be reloaded into R despite being listed in data_pack

# create object storing the indices of predictor layers (from the prediction dataset) for the autocorrelation assessment that will inform block size. Only include continuous numeric variables here. Can use indexing "[-c(x:y)] to exclude them (e.g. exclude climate variables, HF, etc).
ind2 <- which(names(pred_abs_2011) %in% pred.variables2[-21])

# Calculate autocorrelation range
start_time <- Sys.time()
sp.auto.arr2 <- spatialAutoRange(pred_abs_2011[[ind2]])
end_time <- Sys.time()
end_time - start_time#Time difference of 4.746926 mins

# Use spatial blocks to separate train and test folds
start_time <- Sys.time()
set.seed(123)
sp_block_select <-  spatialBlock(
  speciesData = datcombo_sp,
  species = "OCCU",
  rasterLayer = pred_abs_2011[[1]],
  iteration = 250,
  theRange = sp.auto.arr2$range,
  selection = "random",
  maskBySpecies = FALSE,
  k=5
)
end_time <- Sys.time()
end_time - start_time#Time difference of 10.81133 mins

start_time<-Sys.time()
brt2<- brt_blocks(data=datcombo,pred.variables = pred.variables2, lr=0.01,tc=3, output.folder = "2_BRT_outputs/selected_scales_new/test run/", blocks=sp_block_select, save.points.shp = TRUE)  
end_time<-Sys.time()
end_time-start_time

save(sp.auto.arr2, sp_block_select, file="2_BRT_outputs/selected_scales_new/test run/spautoarr2andblocks.RData")
save(brt2, file="2_BRT_outputs/selected_scales_new/test run/brt2.RData")


# Cell level (250m, no Gaussian filter) ####
pred.variables3<-c( 
  "Species_Abie_Bal_v1",#
  #"Species_Abie_Bal_v1_Gauss250",#
  #"Species_Abie_Bal_v1_Gauss750",#
  "Species_Acer_Sah_v1",#
  #"Species_Acer_Sah_v1_Gauss250",#
  #"Species_Acer_Sah_v1_Gauss750",#
  "Species_Acer_Rub_v1",#
  #"Species_Acer_Rub_v1_Gauss250",#
  #"Species_Acer_Rub_v1_Gauss750",#
  "Species_Acer_Spi_v1",#
  #"Species_Acer_Spi_v1_Gauss250",#
  #"Species_Acer_Spi_v1_Gauss750",#
  "Species_Betu_All_v1",#
  #"Species_Betu_All_v1_Gauss250",#
  #"Species_Betu_All_v1_Gauss750",#
  "Species_Betu_Pap_v1",#
  #"Species_Betu_Pap_v1_Gauss250",#
  #"Species_Betu_Pap_v1_Gauss750",#
  "Species_Fagu_Gra_v1",#
  #"Species_Fagu_Gra_v1_Gauss250",#
  #"Species_Fagu_Gra_v1_Gauss750",#
  "Species_Frax_Ame_v1",#
  #"Species_Frax_Ame_v1_Gauss250",#
  #"Species_Frax_Ame_v1_Gauss750",#
  "Species_Lari_Lar_v1",#
  #"Species_Lari_Lar_v1_Gauss250",#
  #"Species_Lari_Lar_v1_Gauss750",#
  "Species_Pice_Gla_v1",#
  #"Species_Pice_Gla_v1_Gauss250",#
  #"Species_Pice_Gla_v1_Gauss750",#
  "Species_Pice_Rub_v1",#
  #"Species_Pice_Rub_v1_Gauss250",#
  #"Species_Pice_Rub_v1_Gauss750",#
  "Species_Pice_Mar_v1",#
  #"Species_Pice_Mar_v1_Gauss250",#
  #"Species_Pice_Mar_v1_Gauss750",#
  "Species_Pinu_Ban_v1",#
  #"Species_Pinu_Ban_v1_Gauss250",#
  #"Species_Pinu_Ban_v1_Gauss750",#
  "Species_Pinu_Res_v1",#
  #"Species_Pinu_Res_v1_Gauss250",#
  #"Species_Pinu_Res_v1_Gauss750",#
  "Species_Pinu_Str_v1",#
  #"Species_Pinu_Str_v1_Gauss250",#
  #"Species_Pinu_Str_v1_Gauss750",#
  "Species_Popu_Bal_v1",#
  #"Species_Popu_Bal_v1_Gauss250",#
  #"Species_Popu_Bal_v1_Gauss750",#
  "Species_Quer_Rub_v1",#
  #"Species_Quer_Rub_v1_Gauss250",#
  #"Species_Quer_Rub_v1_Gauss750",#
  "Species_Tsug_Can_v1",#
  #"Species_Tsug_Can_v1_Gauss250",#
  #"Species_Tsug_Can_v1_Gauss750",#
  "Structure_Biomass_TotalLiveAboveGround_v1",
  #"Structure_Biomass_TotalLiveAboveGround_v1_Gauss250",
  #"Structure_Biomass_TotalLiveAboveGround_v1_Gauss750",
  "Structure_Stand_Age_v1",
  #"Structure_Stand_Age_v1_Gauss250",
  #"Structure_Stand_Age_v1_Gauss750",
  "wtbl250",
  #"wtbl250_modal3x3",
  #"wtbl250_modal5x5",
  "CTI250",
  #"CTI250_Gauss250",
  #"CTI250_Gauss750",
  "roadsNNS",
  #"roadsNNS_Gauss250",
  #"roadsNNS_Gauss750",
  "urbagNNS",
  #"urbagNNS_Gauss250",
  #"urbagNNS_Gauss750",
  "watNNS",
  #"watNNS_Gauss250",
  #"watNNS_Gauss750",
  "ARU"
)

# create object storing the indices of predictor layers (from the prediction dataset) for the autocorrelation assessment that will inform block size. Only include continuous numeric variables here. Can use indexing "[-c(x:y)] to exclude them (e.g. exclude climate variables, HF, etc).
ind3 <- which(names(pred_abs_2011) %in% pred.variables3[-21])

# Calculate autocorrelation range
start_time <- Sys.time()
sp.auto.arr3 <- spatialAutoRange(pred_abs_2011[[ind3]])
end_time <- Sys.time()
end_time - start_time#Time difference of 2.045344 mins

# Use spatial blocks to separate train and test folds
start_time <- Sys.time()
set.seed(123)
sp_block_cell <-  spatialBlock(
  speciesData = datcombo_sp,
  species = "OCCU",
  rasterLayer = pred_abs_2011[[1]],
  iteration = 250,
  theRange = sp.auto.arr3$range,
  selection = "random",
  maskBySpecies = FALSE,
  k=5
)
end_time <- Sys.time()
end_time - start_time#Time difference of 10.75861 mins

start_time<-Sys.time()
brt3<- brt_blocks(data=datcombo,pred.variables = pred.variables3, lr=0.00001,tc=2, output.folder = "2_BRT_outputs/cell_level_new/test run/", blocks=sp_block_cell, save.points.shp = FALSE)  
end_time<-Sys.time()
end_time-start_time

save(sp.auto.arr3, sp_block_cell, file="2_BRT_outputs/cell_level_new/test run/spautoarr3andblocks.RData")
save(brt3, file="2_BRT_outputs/cell_level_new/test run/brt3.RData")

# Only Gaussian filter with sigma = 250m ####
pred.variables4<-c( 
  #"Species_Abie_Bal_v1",#
  "Species_Abie_Bal_v1_Gauss250",#
  #"Species_Abie_Bal_v1_Gauss750",#
  #"Species_Acer_Sah_v1",#
  "Species_Acer_Sah_v1_Gauss250",#
  #"Species_Acer_Sah_v1_Gauss750",#
  #"Species_Acer_Rub_v1",#
  "Species_Acer_Rub_v1_Gauss250",#
  #"Species_Acer_Rub_v1_Gauss750",#
  #"Species_Acer_Spi_v1",#
  "Species_Acer_Spi_v1_Gauss250",#
  #"Species_Acer_Spi_v1_Gauss750",#
  #"Species_Betu_All_v1",#
  "Species_Betu_All_v1_Gauss250",#
  #"Species_Betu_All_v1_Gauss750",#
  #"Species_Betu_Pap_v1",#
  "Species_Betu_Pap_v1_Gauss250",#
  #"Species_Betu_Pap_v1_Gauss750",#
  #"Species_Fagu_Gra_v1",#
  "Species_Fagu_Gra_v1_Gauss250",#
  #"Species_Fagu_Gra_v1_Gauss750",#
  #"Species_Frax_Ame_v1",#
  "Species_Frax_Ame_v1_Gauss250",#
  #"Species_Frax_Ame_v1_Gauss750",#
  #"Species_Lari_Lar_v1",#
  "Species_Lari_Lar_v1_Gauss250",#
  #"Species_Lari_Lar_v1_Gauss750",#
  #"Species_Pice_Gla_v1",#
  "Species_Pice_Gla_v1_Gauss250",#
  #"Species_Pice_Gla_v1_Gauss750",#
  #"Species_Pice_Rub_v1",#
  "Species_Pice_Rub_v1_Gauss250",#
  #"Species_Pice_Rub_v1_Gauss750",#
  #"Species_Pice_Mar_v1",#
  "Species_Pice_Mar_v1_Gauss250",#
  #"Species_Pice_Mar_v1_Gauss750",#
  #"Species_Pinu_Ban_v1",#
  "Species_Pinu_Ban_v1_Gauss250",#
  #"Species_Pinu_Ban_v1_Gauss750",#
  #"Species_Pinu_Res_v1",#
  "Species_Pinu_Res_v1_Gauss250",#
  #"Species_Pinu_Res_v1_Gauss750",#
  #"Species_Pinu_Str_v1",#
  "Species_Pinu_Str_v1_Gauss250",#
  #"Species_Pinu_Str_v1_Gauss750",#
  #"Species_Popu_Bal_v1",#
  "Species_Popu_Bal_v1_Gauss250",#
  #"Species_Popu_Bal_v1_Gauss750",#
  #"Species_Quer_Rub_v1",#
  "Species_Quer_Rub_v1_Gauss250",#
  #"Species_Quer_Rub_v1_Gauss750",#
  #"Species_Tsug_Can_v1",#
  "Species_Tsug_Can_v1_Gauss250",#
  #"Species_Tsug_Can_v1_Gauss750",#
  #"Structure_Biomass_TotalLiveAboveGround_v1",
  "Structure_Biomass_TotalLiveAboveGround_v1_Gauss250",
  #"Structure_Biomass_TotalLiveAboveGround_v1_Gauss750",
  #"Structure_Stand_Age_v1",
  "Structure_Stand_Age_v1_Gauss250",
  #"Structure_Stand_Age_v1_Gauss750",
  #"wtbl250",
  "wtbl250_modal3x3",
  #"wtbl250_modal5x5",
  "CTI250",
  #"CTI250_Gauss250",
  #"CTI250_Gauss750",
  #"roadsNNS",
  "roadsNNS_Gauss250",
  #"roadsNNS_Gauss750",
  #"urbagNNS",
  "urbagNNS_Gauss250",
  #"urbagNNS_Gauss750",
  #"watNNS",
  "watNNS_Gauss250",
  #"watNNS_Gauss750",
  "ARU"
)

# create object storing the indices of predictor layers (from the prediction dataset) for the autocorrelation assessment that will inform block size. Only include continuous numeric variables here. Can use indexing "[-c(x:y)] to exclude them (e.g. exclude climate variables, HF, etc).
ind4 <- which(names(pred_abs_2011) %in% pred.variables4[-21])

# Calculate autocorrelation range
start_time <- Sys.time()
sp.auto.arr4 <- spatialAutoRange(pred_abs_2011[[ind4]])
end_time <- Sys.time()
end_time - start_time#Time difference of 1.301845 mins

# Use spatial blocks to separate train and test folds
start_time <- Sys.time()
set.seed(123)
sp_block_GF250 <-  spatialBlock(
  speciesData = datcombo_sp,
  species = "OCCU",
  rasterLayer = pred_abs_2011[[1]],
  iteration = 250,
  theRange = sp.auto.arr4$range,
  selection = "random",
  maskBySpecies = FALSE,
  k=5
)
end_time <- Sys.time()
end_time - start_time#Time difference of 14.36478 mins

start_time<-Sys.time()
brt4<- brt_blocks(data=datcombo,pred.variables = pred.variables4, lr=0.01,tc=3, output.folder = "2_BRT_outputs/GFsigma250m_new/test run/", blocks=sp_block_GF250, save.points.shp = TRUE)  
end_time<-Sys.time()
end_time-start_time

save(sp.auto.arr4, sp_block_GF250, file="2_BRT_outputs/GFsigma250m_new/test run/spautoarr4andblocks.RData")
save(brt4, file="2_BRT_outputs/GFsigma250m_new/test run/brt4.RData")

# Only Gaussian filter with sigma = 750m ####
pred.variables5<-c( 
  #"Species_Abie_Bal_v1",#
  #"Species_Abie_Bal_v1_Gauss250",#
  "Species_Abie_Bal_v1_Gauss750",#
  #"Species_Acer_Sah_v1",#
  #"Species_Acer_Sah_v1_Gauss250",#
  "Species_Acer_Sah_v1_Gauss750",#
  #"Species_Acer_Rub_v1",#
  #"Species_Acer_Rub_v1_Gauss250",#
  "Species_Acer_Rub_v1_Gauss750",#
  #"Species_Acer_Spi_v1",#
  #"Species_Acer_Spi_v1_Gauss250",#
  "Species_Acer_Spi_v1_Gauss750",#
  #"Species_Betu_All_v1",#
  #"Species_Betu_All_v1_Gauss250",#
  "Species_Betu_All_v1_Gauss750",#
  #"Species_Betu_Pap_v1",#
  #"Species_Betu_Pap_v1_Gauss250",#
  "Species_Betu_Pap_v1_Gauss750",#
  #"Species_Fagu_Gra_v1",#
  #"Species_Fagu_Gra_v1_Gauss250",#
  "Species_Fagu_Gra_v1_Gauss750",#
  #"Species_Frax_Ame_v1",#
  #"Species_Frax_Ame_v1_Gauss250",#
  "Species_Frax_Ame_v1_Gauss750",#
  #"Species_Lari_Lar_v1",#
  #"Species_Lari_Lar_v1_Gauss250",#
  "Species_Lari_Lar_v1_Gauss750",#
  #"Species_Pice_Gla_v1",#
  #"Species_Pice_Gla_v1_Gauss250",#
  "Species_Pice_Gla_v1_Gauss750",#
  #"Species_Pice_Rub_v1",#
  #"Species_Pice_Rub_v1_Gauss250",#
  "Species_Pice_Rub_v1_Gauss750",#
  #"Species_Pice_Mar_v1",#
  #"Species_Pice_Mar_v1_Gauss250",#
  "Species_Pice_Mar_v1_Gauss750",#
  #"Species_Pinu_Ban_v1",#
  #"Species_Pinu_Ban_v1_Gauss250",#
  "Species_Pinu_Ban_v1_Gauss750",#
  #"Species_Pinu_Res_v1",#
  #"Species_Pinu_Res_v1_Gauss250",#
  "Species_Pinu_Res_v1_Gauss750",#
  #"Species_Pinu_Str_v1",#
  #"Species_Pinu_Str_v1_Gauss250",#
  "Species_Pinu_Str_v1_Gauss750",#
  #"Species_Popu_Bal_v1",#
  #"Species_Popu_Bal_v1_Gauss250",#
  "Species_Popu_Bal_v1_Gauss750",#
  #"Species_Quer_Rub_v1",#
  #"Species_Quer_Rub_v1_Gauss250",#
  "Species_Quer_Rub_v1_Gauss750",#
  #"Species_Tsug_Can_v1",#
  #"Species_Tsug_Can_v1_Gauss250",#
  "Species_Tsug_Can_v1_Gauss750",#
  #"Structure_Biomass_TotalLiveAboveGround_v1",
  #"Structure_Biomass_TotalLiveAboveGround_v1_Gauss250",
  "Structure_Biomass_TotalLiveAboveGround_v1_Gauss750",
  #"Structure_Stand_Age_v1",
  #"Structure_Stand_Age_v1_Gauss250",
  "Structure_Stand_Age_v1_Gauss750",
  #"wtbl250",
  #"wtbl250_modal3x3",
  "wtbl250_modal5x5",
  #"CTI250",
  #"CTI250_Gauss250",
  "CTI250_Gauss750",
  #"roadsNNS",
  #"roadsNNS_Gauss250",
  "roadsNNS_Gauss750",
  #"urbagNNS",
  #"urbagNNS_Gauss250",
  "urbagNNS_Gauss750",
  #"watNNS",
  #"watNNS_Gauss250",
  "watNNS_Gauss750",
  "ARU"
)

# create object storing the indices of predictor layers (from the prediction dataset) for the autocorrelation assessment that will inform block size. Only include continuous numeric variables here. Can use indexing "[-c(x:y)] to exclude them (e.g. exclude climate variables, HF, etc).
ind5 <- which(names(pred_abs_2011) %in% pred.variables5[-21])

# Calculate autocorrelation range
start_time <- Sys.time()
sp.auto.arr5 <- spatialAutoRange(pred_abs_2011[[ind5]])
end_time <- Sys.time()
end_time - start_time#Time difference of 1.093092 mins

# Use spatial blocks to separate train and test folds
start_time <- Sys.time()
set.seed(123)
sp_block_GF750 <-  spatialBlock(
  speciesData = datcombo_sp,
  species = "OCCU",
  rasterLayer = pred_abs_2011[[1]],
  iteration = 250,
  theRange = sp.auto.arr5$range,
  selection = "random",
  maskBySpecies = FALSE,
  k=5
)
end_time <- Sys.time()
end_time - start_time#Time difference of 3.815102 mins

start_time<-Sys.time()
brt5<- brt_blocks(data=datcombo,pred.variables = pred.variables5, lr=0.01,tc=3, output.folder = "2_BRT_outputs/GFsigma750m_new/test run/", blocks=sp_block_GF750, save.points.shp = TRUE)  
end_time<-Sys.time()
end_time-start_time

save(sp.auto.arr5, sp_block_GF750, file="2_BRT_outputs/GFsigma750m_new/test run/spautoarr5andblocks.RData")
save(brt5, file="2_BRT_outputs/GFsigma750m_new/test run/brt5.RData")


save.image("2_BRT_outputs/outputs.RData")

# Comparison of the different models ####
library(ggplot2)

# Model deviance

df_devplot<- data.frame(grp=c("Full model",
                      "Selected scales",
                      "cell level",
                      "250m Gaussian smooth",
                      "750m Gaussian smooth"),
                deviance=c(brt1$cv.statistics$deviance.mean,
                           brt2$cv.statistics$deviance.mean,
                           brt3$cv.statistics$deviance.mean,
                           brt4$cv.statistics$deviance.mean,
                           brt5$cv.statistics$deviance.mean),
                se=c(brt1$cv.statistics$deviance.se,
                     brt2$cv.statistics$deviance.se,
                     brt3$cv.statistics$deviance.se,
                     brt4$cv.statistics$deviance.se,
                     brt5$cv.statistics$deviance.se)
)
df_devplot
k<-ggplot(df_devplot, aes(grp,deviance,ymin=deviance-se,ymax=deviance+se))
k+geom_pointrange()

tiff('2_BRT_outputs/test run output RData files/BRTmodels.deviances.tiff', units="in", width=12, height=8, res=300)
k+geom_pointrange()
dev.off()

# correlation
df_corrplot<- data.frame(grp=c("Full model",
                       "Selected scales",
                       "cell level",
                       "250m Gaussian smooth",
                       "750m Gaussian smooth"),
                 correlation=c(brt1$cv.statistics$correlation.mean,
                               brt2$cv.statistics$correlation.mean,
                               brt3$cv.statistics$correlation.mean,
                               brt4$cv.statistics$correlation.mean,
                               brt5$cv.statistics$correlation.mean),
                 se=c(brt1$cv.statistics$correlation.se,
                      brt2$cv.statistics$correlation.se,
                      brt3$cv.statistics$correlation.se,
                      brt4$cv.statistics$correlation.se,
                      brt5$cv.statistics$correlation.se)
)
df_corrplot
k2<-ggplot(df_corrplot, aes(grp,correlation,ymin=correlation-se,ymax=correlation+se))
k2+geom_pointrange()

tiff('2_BRT_outputs/test run output RData files/BRTmodels.correlation.tiff', units="in", width=12, height=8, res=300)
k2+geom_pointrange()
dev.off()

# Calibration:  The first two statistics were the estimated intercepts and slopes of linear regression models of predictions against observations. The intercept measures the magnitude and direction of bias, with values close to 0 indicating low or no bias. The slope yields information about the consistency in the bias as a function of the mean, with a value of 1 indicating a consistent bias if the intercept is a nonzero value.
## intercept
df_calli_int_plot<- data.frame(grp=c("Full model",
                       "Selected scales",
                       "cell level",
                       "250m Gaussian smooth",
                       "750m Gaussian smooth"),
                 calibration.intercept=c(brt1$cv.statistics$calibration.mean[1],
                                         brt2$cv.statistics$calibration.mean[1],
                                         brt3$cv.statistics$calibration.mean[1],
                                         brt4$cv.statistics$calibration.mean[1],
                                         brt5$cv.statistics$calibration.mean[1]),
                 se=c(brt1$cv.statistics$calibration.se[1],
                      brt2$cv.statistics$calibration.se[1],
                      brt3$cv.statistics$calibration.se[1],
                      brt4$cv.statistics$calibration.se[1],
                      brt5$cv.statistics$calibration.se[1])
)
df_calli_int_plot
k3<-ggplot(df_calli_int_plot, aes(grp,calibration.intercept,ymin=calibration.intercept-se,ymax=calibration.intercept+se))
k3+geom_pointrange()

tiff('2_BRT_outputs/test run output RData files/BRTmodels.calibration.intercept.tiff', units="in", width=12, height=8, res=300)
k3+geom_pointrange()
dev.off()

## slope
df_calli_slope_plot<- data.frame(grp=c("Full model",
                       "Selected scales",
                       "cell level",
                       "250m Gaussian smooth",
                       "750m Gaussian smooth"),
                 calibration.slope=c(brt1$cv.statistics$calibration.mean[2],
                                     brt2$cv.statistics$calibration.mean[2],
                                     brt3$cv.statistics$calibration.mean[2],
                                     brt4$cv.statistics$calibration.mean[2],
                                     brt5$cv.statistics$calibration.mean[2]),
                 se=c(brt1$cv.statistics$calibration.se[2],
                      brt2$cv.statistics$calibration.se[2],
                      brt3$cv.statistics$calibration.se[2],
                      brt4$cv.statistics$calibration.se[2],
                      brt5$cv.statistics$calibration.se[2])
)
df_calli_slope_plot
k4<-ggplot(df_calli_slope_plot, aes(grp,calibration.slope,ymin=calibration.slope-se,ymax=calibration.slope+se))
k4+geom_pointrange()

tiff('2_BRT_outputs/test run output RData files/BRTmodels.calibration.slope.tiff', units="in", width=12, height=8, res=300)
k4+geom_pointrange()
dev.off()

#Multi-panel plot comparing BRTs (using F. Denes' results)
library(magick)
library(dplyr)
library(tidyr)
library(magrittr)
# read images and then create a montage
# tile =2 , means arrange the images in 2 columns
# geometry controls the pixel sixe, spacing between each image in the collage output. 
# read the the png files into a list
pngfiles <-
  list.files(
    path = "2_BRT_outputs/old output RData files/",
    recursive = TRUE,
    pattern = "\\.png$",
    full.names = T
  )

magick::image_read(pngfiles) %>%
  magick::image_montage(tile = "2", geometry = "x500+10+5") %>%
  magick::image_convert("jpg") %>%
  magick::image_write(
    format = ".tiff", path = "2_BRT_outputs/brt_comparison_collage.jpg",
    quality = 100
  )

# Plotting deviance for each brt model ####
dev_plot<-function(brt){
  m<-brt
  y.bar <- min(m$cv.values) 
  y.min <- min(m$cv.values - m$cv.loss.ses)
  y.max <- max(m$cv.values + m$cv.loss.ses)
  
  plot(m$trees.fitted, m$cv.values, type = 'l', ylab = "Holdout deviance", xlab = "no. of trees", ylim = c(y.min,y.max))
  abline(h = y.bar, col = 3)
  
  lines(m$trees.fitted, m$cv.values + m$cv.loss.ses, lty=2)  
  lines(m$trees.fitted, m$cv.values - m$cv.loss.ses, lty=2)  
  
  target.trees <- m$trees.fitted[match(TRUE,m$cv.values == y.bar)]
  abline(v = target.trees, col=4)
}

dev_plot(brt5)

names(brt5)
pdf("2_BRT_outputs/test run output RData files/relative-importance.pdf",width=7,height=25)
summary(brt5)
dev.off()

df.summ.brt5<-data.frame(summary(brt5))
write.csv(df.summ.brt5, file="2_BRT_outputs/test run output RData files/relative-importance.csv")

#horizontal bar plot
library(ggplot2)
my.theme <- theme_classic() +
  theme(text=element_text(size=24, family="Arial"),
        axis.text.x=element_text(size=24),
        axis.text.y=element_text(size=24),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

#Manually adjust variable names in CSV file
#df.summ.brt2<-read.csv("2_BRT_outputs/test run output RData files/relative-importance.csv", header=TRUE)

#Using results obtained by F. Denes:
df.summ.brt5<-read.csv("2_BRT_outputs/GFsigma750m_new/relative-importance.csv", header=TRUE)

tiff('2_BRT_outputs/relative-importance.tiff', units="in", width=12, height=8, res=300)
ggplot(df.summ.brt5, aes(reorder(x = Name, rel.inf, mean), y = rel.inf))+
  geom_col(fill = "blue", width = 0.7)+coord_flip()+
  ylab("Relative importance (%)")+
  xlab("Predictor")+my.theme
dev.off()

#Using gbm.plot to generate partial dependence plots
pdf("2_BRT_outputs/GFsigma750m_new/gbm_plot.var-scale.pdf")
gbm.plot(
  brt5,
  n.plots = 10,
  smooth = TRUE,
  plot.layout = c(4, 3),
  common.scale = F,
  write.title = F
)
dev.off()

#Creating custom individual partial dependence plots as PNG files
#Using results obtained by F. Denes:
load("2_BRT_outputs/old output RData files/outputs.RData")
#This would replace the version of brt5 actively created in this session 
#with the brt object created by Francisco
png('2_BRT_outputs/GFsigma750m_new/png_output_folder/partial-dep-plotA.png')
p1<-plot(brt5, 
         i.var = "cti250_Gauss250",
         return.grid=TRUE)
plot(p1, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Comp. topo. index 250 m R.I. 26.80 %")
lines(p1$cti250_Gauss250, p1$y, col="red")
dev.off()

png('2_BRT_outputs/GFsigma750m_new/png_output_folder/partial-dep-plotB.png')
p2<-plot(brt5, 
         i.var = "Species_Betu_Pap_v1_Gauss750",
         return.grid=TRUE)
plot(p2, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Paper birch 750 m (%) R.I. 11.30 %")
lines(p2$Species_Betu_Pap_v1_Gauss750, p2$y, col="red")
dev.off()

png('2_BRT_outputs/GFsigma750m_new/png_output_folder/partial-dep-plotC.png')
p3<-plot(brt5, 
         i.var = "Species_Popu_Tre_v1_Gauss250",
         return.grid=TRUE)
plot(p3, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Trembling aspen 250 m (%) R.I. 9.58 %")
lines(p3$Species_Popu_Tre_v1_Gauss250, p3$y, col="red")
dev.off()

png('2_BRT_outputs/GFsigma750m_new/png_output_folder/partial-dep-plotD.png')
p4<-plot(brt5, 
         i.var = "Species_Lari_Lar_v1_Gauss250",
         return.grid=TRUE)
plot(p4, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Tamarack 250 m (%) R.I. 8.74 %")
lines(p4$Species_Lari_Lar_v1_Gauss250, p4$y, col="red")
dev.off()

png('2_BRT_outputs/GFsigma750m_new/png_output_folder/partial-dep-plotE.png')
p5<-plot(brt5, 
         i.var = "SeismicLineWide",
         return.grid=TRUE)
plot(p5, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="2d seismic local (%) R.I. 8.54 %")
lines(p5$SeismicLineWide, p5$y, col="red")
dev.off()

png('2_BRT_outputs/GFsigma750m_new/png_output_folder/partial-dep-plotF.png')
p6<-plot(brt5, 
         i.var = "TransmissionLine",
         return.grid=TRUE)
plot(p6, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Transmission line local (%) R.I. 7.32 %")
lines(p6$TransmissionLine, p6$y, col="red")
dev.off()

png('2_BRT_outputs/GFsigma750m_new/png_output_folder/partial-dep-plotG.png')
p7<-plot(brt5, 
         i.var = "Species_Pinu_Ban_v1_Gauss750",
         return.grid=TRUE)
plot(p7, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Jack pine 750 m (%) R.I. 6.22 %")
lines(p7$Species_Pinu_Ban_v1_Gauss750, p7$y, col="red")
dev.off()

png('2_BRT_outputs/GFsigma750m_new/png_output_folder/partial-dep-plotH.png')
p8<-plot(brt5, 
         i.var = "Structure_Biomass_TotalLiveAboveGround_v1_Gauss250",
         return.grid=TRUE)
plot(p8, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Above ground biomass 250 m R.I. 4.83 %")
lines(p8$Structure_Biomass_TotalLiveAboveGround_v1_Gauss250, p8$y, col="red")
dev.off()

png('2_BRT_outputs/GFsigma750m_new/png_output_folder/partial-dep-plotI.png')
p9<-plot(brt5, 
         i.var = "Species_Abie_Bal_v1_Gauss750",
         return.grid=TRUE)
plot(p9, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Balsam fir 750 m (%) R.I. 3.80 %")
lines(p9$Species_Abie_Bal_v1_Gauss750, p9$y, col="red")
dev.off()

png('2_BRT_outputs/GFsigma750m_new/png_output_folder/partial-dep-plotJ.png')
p10<-plot(brt5, 
          i.var = "Species_Pice_Mar_v1_Gauss750",
          return.grid=TRUE)
plot(p10, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Black spruce 750 m (%) R.I. 3.22 %")
lines(p10$Species_Pice_Mar_v1_Gauss750, p10$y, col="red")
dev.off()

#create multi-panel plot from PNG files
library(magick)
library(dplyr)
library(tidyr)
library(magrittr)
# read images and then create a montage
# tile =2 , means arrange the images in 2 columns
# geometry controls the pixel sixe, spacing between each image in the collage output. 
# read the the png files into a list
pngfiles <-
  list.files(
    path = "2_BRT_outputs/GFsigma750m_new/png_output_folder",
    recursive = TRUE,
    pattern = "\\.png$",
    full.names = T
  )

magick::image_read(pngfiles) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("jpg") %>%
  magick::image_write(
    format = ".tiff", path = "2_BRT_outputs/pdp_plot_collage.jpg",
    quality = 100
  )


####
# A function to obtain confidence intervals of model predictions ####
boot_brt<-function(data,brtmodel,blocks,pred.data,nsamples=250,output.folder){
  rast <-  predict(pred.data,
                   brtmodel,
                   type = "response",
                   n.trees = brtmodel$n.trees)
  stack<-stack(rast)
  names(stack)[1]<-"model estimate"
  
  z <- output.folder
  
  if (file.exists(z) == FALSE) {
    dir.create(z)
  }
  
  for(i in 1:nsamples){
    
    
    cat("loop",i,"\n") # this prints the loop number on console to track function progress
    
   
    brt <- NULL
    attempt <- 0
    while( is.null(brt) && attempt <= 20 ) {
      attempt <- attempt + 1
      
      sample<-sample(1:nrow(data),size=nrow(data),replace=T)
      data2<-data[sample,]
      
      try(brt <-
            gbm.step(
              data = data2,
              gbm.y = brtmodel$gbm.call$gbm.y,
              gbm.x = brtmodel$gbm.call$gbm.x,
              fold.vector = blocks$foldID[sample],
              n.folds = brtmodel$gbm.call$cv.folds,
              family = brtmodel$gbm.call$family,
              tree.complexity = brtmodel$gbm.call$tree.complexity,
              learning.rate = brtmodel$gbm.call$learning.rate,
              bag.fraction = brtmodel$gbm.call$bag.fraction,
              offset = brtmodel$gbm.call$offset[sample],
              site.weights = data2$wt
            ))
    } 
    
    

    
    
    rast <- predict(pred.data,
                    brt,
                    type = "response",
                    n.trees = brt$n.trees)
    
    
    
    stack <- addLayer(stack, rast)
    names(stack)[i+1]<-paste0("sample",i) 
    
    
    saveRDS(brt, file=paste0(z,"bootstrap_model",i,".R"))
    
    
  }
  
  fun0.05 <- function(x) {quantile(x, probs = 0.05, na.rm = TRUE)}
  lower<- calc(stack[[-1]],fun0.05)
  fun0.95 <- function(x) {quantile(x, probs = 0.95, na.rm = TRUE)}
  upper<- calc(stack[[-1]],fun0.95)
  
  writeRaster(lower, filename=paste0(z, "confint_lower.tif"), format="GTiff",overwrite=TRUE)
  writeRaster(upper, filename=paste0(z, "confint_upper.tif"), format="GTiff",overwrite=TRUE)
  writeRaster(stack, filename=paste0(z, "samples.grd"), format="raster",overwrite=TRUE)
  
  return(stack)
}

start_time <- Sys.time()
confintbrt5<-boot_brt(datcombo,brt5,sp_block_GF750,pred_abs_2011,nsamples=250,output.folder = "2_BRT_outputs/GFsigma750m_new/confint/")
end_time <- Sys.time()
end_time - start_time
#The final model that was selected by Francisco Denes for predictions
#and resampling 250 times was brt5 (the GF750 model). Since
#the BRT results depend in part on the points sampled for training
#and testing data, results including the final model chosen
#can differ each time the BRT models are rerun. 

#resampling and the raster stack of prediction layers stored in 
#the "confint" folder are for the GF750 model when it was run
#by Francisco Denes. The brt object (in this case, brt5) and brt
#model output folder should be changed on line 1010 if another 
#model is going to be used.

#Currently resampling and creation of the raster stack of prediction
#layers is done in a single loop. With a larger study area or more
#data points, it may be necessary to break the loop into one
#loop for creating the BRT resamples and a second loop to create 
#the raster stack of prediction layers. The reason would be due to 
#running out of memory. It may even be necessary to get the raster
#prediction layers in batches of 50 and create 5 raster stacks rather
#than a single stack of 250 prediction layers.
save.image("2_BRT_outputs/outputs.RData")

# Plot population size from density predictions ####
pred_abs_2011<-brick("0_data/1_processed/prediction dataset/abs2011_250m.grd")
#load("2_BRT_outputs/old output RData files/outputs_FDenes.RData")
load("2_BRT_outputs/GFsigma750m_new/test run/brt5.RData")
load("2_BRT_outputs/GFsigma750m_new/test run/spautoarr5andblocks.RData")
#pred.variables5, ind5, and brt_blocks may need to be loaded
#for predict function to work.

library(ggplot2)
library(gbm)
library(dplyr)
library(tidyr)
library(raster)
library(maptools)
library(ncdf4)
library(rasterVis)
library(RColorBrewer)
library(zoo)
library(gridExtra)
library(grid)
library(viridis)
my.theme <- theme_classic() +
  theme(text=element_text(size=16, family="Arial"),
        axis.text.x=element_text(size=16),
        axis.text.y=element_text(size=16),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

rast <-  predict(pred_abs_2011,
                 brt5,
                 type = "response",
                 n.trees = brt5$n.trees)
plot(rast)
#Warning messages:
#1: In predict.gbm(model, blockvals, ...) :
#  predict.gbm does not add the offset to the predicted values.
#...7:
lower<-raster("2_BRT_outputs/GFsigma750m_new/confint/confint_lower.tif")
upper<-raster("2_BRT_outputs/GFsigma750m_new/confint/confint_upper.tif")
plot(lower)
plot(upper)

maxabund<-max(max(rast@data@values, na.rm=T), 
              max(lower@data@max, na.rm=T), 
              max(upper@data@max, na.rm=T))
#lower and upper come from TIF files while rast comes from a raster
#created in this R session so syntax is different

#legends in multi-panel plot are not on a common scale 
#so that differences in predicted density within a plot 
#are more emphasized.

## Modify the palette with your colors
divPal <- brewer.pal(n=9, 'YlGnBu')#or 'PuOr
#divPal[5] <- "#FFFFFF"
divTheme <- rasterTheme(region=divPal)

#province and territory shapefile
provs <-  readOGR("0_data/0_raw/BCR_Terrestrial_master/BCR_Terrestrial_master.shp")
lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs" 
provsproj<-spTransform(provs, CRSobj = lcc_crs)
#oceans
N.America <-  readOGR("0_data/0_raw/North America shapefile/boundary_p_v2_LCC.shp")
water<-N.America[N.America$COUNTRY=="water/agua/d'eau",]
waterproj<-spTransform(water, CRSobj = lcc_crs)

#Mean Predicted Density
mean.dens<-levelplot(rast, margin=F,
                     par.settings = rasterTheme(region=divPal, axis.line = list(col = "transparent"), 
                                                strip.background = list(col = 'transparent'), 
                                                strip.border = list(col = 'transparent')), scales = list(col = "transparent"),
                     main=list(label='Predicted Density (males/ha)',cex=1))+ 
  latticeExtra::layer(sp.lines(provsproj, col="black",lwd = 1))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.polygons(waterproj, fill="lightblue",lwd = 1.5))# extra shapefile data I want overlayed


lower05.dens<-levelplot(lower, margin=F,
                        par.settings = rasterTheme(region=divPal, axis.line = list(col = "transparent"), 
                                                   strip.background = list(col = 'transparent'), 
                                                   strip.border = list(col = 'transparent')), scales = list(col = "transparent"),
                        main=list(label='Density - Lower 95 % CI',cex=1))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.polygons(waterproj, fill="lightblue",lwd = 1.5))# extra shapefile data I want overlayed

upper95.dens<-levelplot(upper, margin=F,
                        par.settings = rasterTheme(region=divPal, axis.line = list(col = "transparent"), 
                                                   strip.background = list(col = 'transparent'), 
                                                   strip.border = list(col = 'transparent')), scales = list(col = "transparent"),
                        main=list(label='Density - Upper 95 % CI',cex=1))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.polygons(waterproj, fill="lightblue",lwd = 1.5))# extra shapefile data I want overlayed

lattice.options(
  layout.heights=list(bottom.padding=list(x=0), top.padding=list(x=0)),
  layout.widths=list(left.padding=list(x=0), right.padding=list(x=0.5))
)


tg<-textGrob("Predicted Canada Warbler Density",gp=gpar(fontsize=15,font=1))
margin <- unit(0.5, "line")
grided<-grid.arrange(mean.dens, lower05.dens, upper95.dens, nrow=1, ncol=3)

tiff("2_BRT_outputs/CanadaWarblerDensity_NNS.tiff", units="in", width=15, height=8, res=300)

grid.arrange(tg, grided,
             heights = unit.c(grobHeight(tg) + 1.2*margin, 
                              unit(1,"null")))
dev.off()

#Estimate population size
preds_brt2<-getValues(rast)[!is.na(getValues(rast))]
density_brt2_250m<-preds_brt2*6.25
sum(density_brt2_250m)#274175.9
abundance_brt2<-matrix(NA,length(density_brt2_250m),100)

for(i in 1:length(density_brt2_250m)){
  abundance_brt2[i,]<- rpois(100,density_brt2_250m[i])
}

mean(colSums(abundance_brt2))#274103.8
sd(colSums(abundance_brt2))#552.478
sum(density_brt2_250m) #274175.9

# 95% CI pop size
upper_brt2<-getValues(upper)[!is.na(getValues(upper))]
upper_brt2_250m<-upper_brt2*6.25
sum(upper_brt2_250m)#442812.8
abundance_upper_brt2<-matrix(NA,length(upper_brt2_250m),100)
for(i in 1:length(upper_brt2_250m)){
  abundance_upper_brt2[i,]<- rpois(100,upper_brt2_250m[i])
}
mean(colSums(abundance_upper_brt2))#442783.6
mean(colSums(abundance_upper_brt2))*2#885567.1

# 5% CI pop size
lower_brt2<-getValues(lower)[!is.na(getValues(lower))]
lower_brt2_250m<-lower_brt2*6.25
sum(lower_brt2_250m)#165446.9
abundance_lower_brt2<-matrix(NA,length(lower_brt2_250m),100)
for(i in 1:length(lower_brt2_250m)){
  abundance_lower_brt2[i,]<- rpois(100,lower_brt2_250m[i])
}
mean(colSums(abundance_lower_brt2))#165481.8
mean(colSums(abundance_lower_brt2))*2#330963.5

