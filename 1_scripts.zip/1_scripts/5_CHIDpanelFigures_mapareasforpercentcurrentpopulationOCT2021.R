#The purpose of this script is to process specific outputs
#from each self-contained Zonation scenario that has been 
#run, creating custom-designed plots in R from that output.

#A multipanel plot of predicted densities:
library(raster)
library(sp)
library(sf)
library(viridis)
library(rasterVis)
library(tmap)
library(rgdal)
library(ggplot2)
tmap_mode("view")  #plot on map using tmap viewer

#province and territory shapefile
provs <-  readOGR("0_data/0_raw/BCR_Terrestrial_master/BCR_Terrestrial_master.shp")
lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs" 
provsproj<-spTransform(provs, CRSobj = lcc_crs)

#protected areas 
PAs <- readOGR("0_data/0_raw/Protected Areas/CPCAD2019.shp") 
PA.NovaScotia<-PAs[PAs$LOC_E=="Nova Scotia",]
PAproj <- spTransform(PA.NovaScotia, CRSobj = lcc_crs) # reproject PA rasters to be lcc

#oceans
N.America <-  readOGR("0_data/0_raw/North America shapefile/boundary_p_v2_LCC.shp")
water<-N.America[N.America$COUNTRY=="water/agua/d'eau",]
lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs" 
waterproj<-spTransform(water, CRSobj = lcc_crs)


current.ns<-raster("0_data/1_processed/Zonation Scenarios Run/Oct 2021 BestCaseScenario/PresentPredictedDensity_mean.tif")
ncell(current.ns)#2047212
ncell(current.ns[!is.na(current.ns)])#417648
#Total area: 417648 cells * 6.25 ha/cell = 2,610,300 ha
current.ns.rp<-projectRaster(current.ns, crs=lcc_crs)
current.2100.ns.best<-raster("0_data/1_processed/Zonation Scenarios Run/Oct 2021 BestCaseScenario/ZonationMean_CAWA_NovaScotia_BestCase.tif")
current.2100.ns.best.rp<-projectRaster(current.2100.ns.best, crs=lcc_crs)
current.2100.ns.medium<-raster("0_data/1_processed/Zonation Scenarios Run/Oct 2021 MediumCaseScenario/ZonationMean_CAWA_NovaScotia_MediumCase.tif")
current.2100.ns.medium.rp<-projectRaster(current.2100.ns.medium, crs=lcc_crs)
current.2100.ns.worst<-raster("0_data/1_processed/Zonation Scenarios Run/Oct 2021 WorstCaseScenario/ZonationMean_CAWA_NovaScotia_WorstCase.tif")
current.2100.ns.worst.rp<-projectRaster(current.2100.ns.worst, crs=lcc_crs)
iStack<-stack(current.ns.rp, 
              current.2100.ns.best.rp,
              current.2100.ns.medium.rp,
              current.2100.ns.worst.rp)


names(iStack) <- c("a", "b", "c", "d")#rename the files for the panel plot 'names'

LBDG<-colorRampPalette(c("tan","darkgreen"))
WHDG<-colorRampPalette(c("white","darkgreen"))

#setting my trellis themes
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

tiff("3_Zonation_outputs_processed_in_R/MultipanelDensityMaps.tiff", units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStack,
                     margin=FALSE, # removes the histograms at the margins                    
                     colorkey=list(
                       space='bottom', # location for legend bar              
                       #height=0.5, width=0.5,
                       labels=list(at=seq(0,1,0.2), font=20, cex=2), # tick labels on legend
                       axis.line=list(col='black') # border of legend bar and ticks
                     ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=WHDG) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="black",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.polygons(PAproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.polygons(waterproj, fill="lightblue",lwd = 1.5))# extra shapefile data I want overlayed
dev.off()

#For the north Nova Scotia study area, I will create three
#sets of maps from Zonation outputs. Each set will contain a panel colouring
#pixels according to their conservation priority on a continuous
#gradient. The second panel will identify all the pixels
#that are required for conservation to maintain the current
#population of Canada Warblers in the study area.

#Current population from mean density raster within Landis area:
#38282.82 (58% of best case scenario)

#The three sets of maps are:
#Best case scenario (Current density + CAWA density in 2100
#under best case scenario)=Baseline Climate/High CPRS Harvest
#66430.47

#Medium case scenario (Current density + CAWA density in 2100
#under medium case scenario)=RCP 4.5/EBFM Harvest
#46057.53

#Worst case scenario (Current density + CAWA density in 2100
#under worst case scenario)=RCP 8.5/EBFM Harvest
#38220.35

library(raster)
library(sp)
library(sf)
library(viridis)
library(rasterVis)
library(tmap)
library(rgdal)
library(ggplot2)
tmap_mode("view")  #plot on map using tmap viewer

#province and territory shapefile
provs <-  readOGR("0_data/BCR_Terrestrial_master/BCR_Terrestrial_master.shp")
#provs <-  readOGR("0_data/Canada shapefile/gpr_000a11a_e/gpr_000a11a_e.shp")
lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs" 
provsproj<-spTransform(provs, CRSobj = lcc_crs)

#protected areas 
PAs <- readOGR("0_data/Protected Areas/CPCAD2019.shp") 
PA.NovaScotia<-PAs[PAs$LOC_E=="Nova Scotia",]
PAproj <- spTransform(PA.NovaScotia, CRSobj = lcc_crs) # reproject PA rasters to be lcc

setwd("2_outputs/Zonation Scenarios Run/compressed tif output")
file_list <- list.files(pattern = "rank.compressed.tif$")#list the Zonation output rasters
rastList <- lapply(file_list, raster)

#rastList[[1]] needs to be cropped to same dimensions as other rastlist objects

pred.crop <- crop(rastList[[1]], rastList[[2]], snap="out")
pred.res<-resample(pred.crop, rastList[[2]], method="bilinear")
rastList[[1]] <- mask(x=pred.res, mask=rastList[[2]])


#stack the rasters for the panel plot
#iStack <- (trim(rastList[[1]])) #could also trim here with padding if needed e.g., (trim(rastList[[1]], padding=20))

#setwd("D:/CWS Wood Thrush Contract/CHID previous work Francisco/CHID regional NS BRT/Landscape simulation results April 2021/2_outputs/Zonation Scenarios Run/panels in R")
#for (i in 2:length(rastList)) {
  # grab the ith raster from the list
  #iRast <- rastList[[i]]
  # trim the ith raster 
  #iTrim <- trim(iRast)
  # stack the ith raster 
  #iStack <- stack(iStack, iTrim)
  #print(i)
#}

#projection of iStack: "+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs "

names(iStack) <- c("A", "B", "C", "D")#rename the files for the panel plot 'names'

#colour ramp for raster
bluegreen.colors2 <- colorRampPalette(c("#FFFACD", 
                                        "#FFF68F", 
                                        "#ADFF2F", 
                                        "greenyellow", 
                                        "#00CD00", 
                                        "green3", 
                                        "mediumturquoise", 
                                        "#007FFF", 
                                        "blue", 
                                        "purple", 
                                        "red"), space="Lab")

LBDG<-colorRampPalette(c("tan","darkgreen"))
fourcol<-colorRampPalette(c("yellow","blue","lightgreen","darkgreen","white"))


#setting my trellis themes
library(lattice)
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

setwd("D:/CWS Wood Thrush Contract/CHID previous work Francisco/CHID regional NS BRT/Landscape simulation results April 2021/2_outputs/Zonation Scenarios Run/panels in R")
tiff('NovaScotiaMultipanelZonationOct4.tiff', units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStack,
                     margin=FALSE, # removes the histograms at the margins                    
                     colorkey=list(
                       space='bottom', # location for legend bar              
                       #height=0.5, width=0.5,
                       labels=list(at=seq(0,1,0.2), font=20, cex=2), # tick labels on legend
                       axis.line=list(col='black') # border of legend bar and ticks
                     ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=LBDG) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  #latticeExtra::layer(sp.lines(AlPacproj, col="black",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.polygons(PAproj, col="black",lwd = 1.5)) # extra shapefile data I want overlayed
dev.off()

############
#example code to create discrete value rasters for figures with CHID identified
#these rasters could then be stacked in the above code for panels. 

#setwd("D:/CWS Wood Thrush Contract/CHID previous work Francisco/CHID regional NS BRT/Landscape simulation results April 2021/2_outputs/Zonation Scenarios Run/compressed tif output")
#LC1 Current Distribution Only 16 % cutoff
LC1_0 <- raster('2_outputs/Zonation Scenarios Run/LC1LDD_caz_dbs_ssi_unc/LC1LDDLDD_caz_dbs_ssi_unc_out/LC1LDD_caz_dbs_ssi_unc_out.rank.compressed.tif')
LC1_0.b <- LC1_0
LC1_0.b[LC1_0 < (0.15877)] <- 0 
#what land you can lose (~15.88%) before starting to lose habitat for 100 % of current population
LC1_0.b[LC1_0 >= 0.15877] <- 1 
#what land you need (100-15.877) to maintain habitat for 100 % of current population
LC1_0.b[LC1_0 >= 0.64805] <- 2 
#what land you need (100-64.805) to maintain habitat for 90 % of current population
LC1_0.b[LC1_0 >= 0.80931] <- 3 
#what land you need (100-80.931) to maintain habitat for 75 % of current population
LC1_0.b[LC1_0 >= 0.92564] <- 4 
#what land you need to maintain habitat for 50 % of current population
plot(LC1_0.b)


#view
tm_shape(LC1_0.b) + tm_raster()
plot(LC1_0.b)
writeRaster(LC1_0.b, filename="2_outputs/Zonation Scenarios Run/LC1LDD_caz_dbs_ssi_unc/LC1LDDLDD_caz_dbs_ssi_unc_out/LC1LDD_caz_dbs_ssi_unc_out_perc_popn_range.tif", overwrite=TRUE)

#Best Case Scenario
#LC3 Baseline Climate High Clearcut
#Future popn. from Landis study area in NS: 66430.47
#Present popn. from same area: 38282.82 (57.63% of future popn.)

LC3_0 <- raster('2_outputs/Zonation Scenarios Run/Oct 2021 BestCaseScenario/outputs/LC3_LDD_LC1_HighCPRS.rank.compressed.tif')
LC3_0.b <- LC3_0
#100 % of current popn / 58 % of future popn / 
LC3_0.b[LC3_0 < 0.36498] <- 0 
#what land you can lose before starting to lose habitat for 100 % of current population
LC3_0.b[LC3_0 >= 0.36498] <- 1 
#what land you need to maintain habitat for 100 % of current population
LC3_0.b[LC3_0 >= 0.92043] <- 2 
#what land you need to maintain habitat for 90 % of current population
LC3_0.b[LC3_0 >= 0.96293] <- 3 
#what land you need to maintain habitat for 75 % of current population
LC3_0.b[LC3_0 >= 0.98693] <- 4 
#what land you need to maintain habitat for 50 % of current population
plot(LC3_0.b)


#view
tm_shape(LC3_0.b) + tm_raster()
plot(LC3_0.b)
writeRaster(LC3_0.b, filename="2_outputs/Zonation Scenarios Run/Oct 2021 BestCaseScenario/outputs/LC3_LDD_LC1_HighCPRS_perc_popn_range.tif", overwrite=TRUE)

#Medium Case Scenario
#LC3 RCP 4.5 Climate EBFM Harvest 42.7% land can be removed while maintaining current population
LC3_0.6 <- raster('2_outputs/Zonation Scenarios Run/Oct 2021 MediumCaseScenario/outputs/LC3_LDD_LC1_EBFM.rank.compressed.tif')
LC3_0.6b <- LC3_0.6
#100 % of current popn / 83 % of future popn / 
LC3_0.6b[LC3_0.6 < 0.45897] <- 0 
#what land you can lose before starting to lose habitat for 100 % of current population
LC3_0.6b[LC3_0.6 >= 0.45897] <- 1 
#what land you need to maintain habitat for 100 % of current population
LC3_0.6b[LC3_0.6 >= 0.91243] <- 2 
#what land you need to maintain habitat for 90 % of current population
LC3_0.6b[LC3_0.6 >= 0.96193] <- 3 
#what land you need (100-86.094) to maintain habitat for 75 % of current population
LC3_0.6b[LC3_0.6 >= 0.98593] <- 4 
#what land you need to maintain habitat for 50 % of current population
plot(LC3_0.6b)

#view
tm_shape(LC3_0.6b) + tm_raster()
plot(LC3_0.6b)
writeRaster(LC3_0.6b, filename="2_outputs/Zonation Scenarios Run/Oct 2021 MediumCaseScenario/outputs/LC3_LDD_LC1_EBFM_perc_popn_range.tif", overwrite=TRUE)

#Worst-case scenario - LC3 RCP 8.5 EBFM Harvest
LC3_rcp85.6 <- raster('2_outputs/Zonation Scenarios Run/Oct 2021 WorstCaseScenario/outputs/LC3_LDD_LC1_EBFM.rank.compressed.tif')
LC3_rcp85.6b <- LC3_rcp85.6

LC3_rcp85.6b[LC3_rcp85.6 < (0.44097)] <- 0 
#what land you can lose before starting to lose habitat for 100 % of current population
LC3_rcp85.6b[LC3_rcp85.6 >= 0.44097] <- 1 
#what land you need to maintain habitat for 100 % of current population
LC3_rcp85.6b[LC3_rcp85.6 >= 0.91143] <- 2 
#what land you need to maintain habitat for 90 % of current population
LC3_rcp85.6b[LC3_rcp85.6 >= 0.95993] <- 3 
#what land you need to maintain habitat for 75 % of current population
LC3_rcp85.6b[LC3_rcp85.6 >= 0.98543] <- 4 
#what land you need to maintain habitat for 50 % of current population
plot(LC3_rcp85.6b)

#view
tm_shape(LC3_rcp85.6b) + tm_raster()
plot(LC3_rcp85.6b)

#view
tm_shape(LC3_rcp85.6b) + tm_raster()
plot(LC3_rcp85.6b)
writeRaster(LC3_rcp85.6b, filename="2_outputs/Zonation Scenarios Run/Oct 2021 WorstCaseScenario/outputs/LC3_LDD_LC1_EBFM.rank_perc_popn_range.tif", overwrite=TRUE)


iStackB<-stack(LC1_0.b,
               LC3_0.b,
               LC3_0.6b, 
               LC3_rcp85.6b)

#first raster needs to be clipped to dimensions of other rasters
pred.crop <- crop(LC1_0.b, LC3_0.b, snap="out")
LC1_0.b2 <- mask(x=pred.crop, mask=LC3_0.b)

iStackB<-stack(LC1_0.b2,
               LC3_0.b,
               LC3_0.6b, 
               LC3_rcp85.6b)



names(iStackB) <- c("a", "b", "c", "d")#

#setting my trellis themes
library(lattice)
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

multicols<-colorRampPalette(c("yellow","lightgreen","darkgreen","blue","violet"))
multicols(5)

#white=0
#yellow=up to 100% (least important but still wanted)
#blue=up to 75% (next most important)
#light green=up to 50% (next most important)
#dark green=up to 25% (the most important)

tiff('2_outputs/Zonation Scenarios Run/NovaScotiaMultipanelZonationOct4percentagecurrent.tiff', units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStackB,
                     margin=FALSE, 
                     # removes the histograms at the margins
                     colorkey=FALSE,
                     # colorkey=list(
                     #   space='bottom', # location for legend bar
                     #   height=0.5, width=0.5,
                     #   labels=list(at=seq(0,4,1), font=20, cex=2), # tick labels on legend
                     #   axis.line=list(col='black') # border of legend bar and ticks
                     # ),
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=multicols) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.polygons(PAproj, col="black",lwd = 1.5)) # extra shapefile data I want overlayed
dev.off()

#ABD9E9
heatramp<- colorRampPalette(c("#FFFFFF","#FFFFBF","#FEE090", "#F46D43", "#A50026") ) #set the colours #individual colours for colour ramp from white through yellow and orange to red
y2bramp<-colorRampPalette(c("#FFFFFF","#FFFFBF","#90EE90", "#006400", "#00008B") ) #set the colours #individual colours for colour ramp from white through yellow and green to dark blue
tiff('2_outputs/Zonation Scenarios Run/NovaScotiaMultipanelZonationOct4percentagecurrentB.tiff', units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStackB,
                     margin=FALSE, layout=c(2,2),
                     # removes the histograms at the margins
                     colorkey=FALSE,
                     # colorkey=list(
                     #   space='bottom', # location for legend bar
                     #   height=0.5, width=0.5,
                     #   labels=list(at=seq(0,4,1), font=20, cex=2), # tick labels on legend
                     #   axis.line=list(col='black') # border of legend bar and ticks
                     # ),
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=heatramp) + # color scheme
  latticeExtra::layer(sp.polygons(PAproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.lines(provsproj, col="black",lwd = 2))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.polygons(waterproj, fill="lightblue",lwd = 1.5))
dev.off()

tiff('2_outputs/Zonation Scenarios Run/NovaScotiaMultipanelZonationNov6percentagecurrentB.tiff', units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStackB,
                     margin=FALSE, layout=c(2,2),
                     # removes the histograms at the margins
                     colorkey=FALSE,
                     # colorkey=list(
                     #   space='bottom', # location for legend bar
                     #   height=0.5, width=0.5,
                     #   labels=list(at=seq(0,4,1), font=20, cex=2), # tick labels on legend
                     #   axis.line=list(col='black') # border of legend bar and ticks
                     # ),
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=y2bramp) + # color scheme
  latticeExtra::layer(sp.polygons(PAproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.lines(provsproj, col="black",lwd = 2))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.polygons(waterproj, fill="lightblue",lwd = 1.5))
dev.off()


#Runtime plots
library(ggplot2)
library(grid)
library(gridExtra)

mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

current.ns.rt<-read.csv("2_outputs/Zonation Scenarios Run/LC1LDD_caz_dbs_ssi_unc/LC1LDDLDD_caz_dbs_ssi_unc_out/LC1LDD_caz_dbs_ssi_unc_out.runtimeplot.csv")
plot1<- ggplot(data=current.ns.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_currentpopn_remaining),color="darkred")+
  geom_vline(xintercept = 0.15877,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 100 % of current population
  geom_vline(xintercept = 0.6485,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 90 % of current population
  geom_vline(xintercept = 0.80931,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 75 % of current population
  geom_vline(xintercept = 0.92564,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in Nova Scotia", y="Proportion of Current Population Left", size=5)+
  annotate("text", x= 0.17, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.66, y = 0,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.82, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.94, y = 0,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot1, file="2_outputs/Zonation Scenarios Run/LC1LDD_caz_dbs_ssi_unc/LC1LDDLDD_caz_dbs_ssi_unc_out/LC1LDD_caz_dbs_ssi_unc_out.runtimeplot.png", units="in", width=10, height=8)

current.2100.ns.best.rt<-read.csv("2_outputs/Zonation Scenarios Run/Oct 2021 BestCaseScenario/outputs/LC3_LDD_LC1_HighCPRS.runtimeplot.csv")
plot2<- ggplot(data=current.2100.ns.best.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.36498,  size=0.5, linetype="dashed")+
  #what land you need to maintain habitat for 100 % of current population in 2100
  geom_vline(xintercept = 0.92043,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 90 % of current population
  geom_vline(xintercept = 0.96293,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 75 % of current population
  geom_vline(xintercept = 0.98693,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in Nova Scotia (Best case)", y="Proportion of Future Population Left", size=5)+
  annotate("text", x= 0.38, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.94, y = 0.5,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.98, y = 0.5,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 1.0, y = 0.5,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot2, file="2_outputs/Zonation Scenarios Run/Oct 2021 BestCaseScenario/outputs/LC3_LDD_LC1_HighCPRS.runtimeplot.png", units="in", width=10, height=8)

current.2100.ns.medium.rt<-read.csv("2_outputs/Zonation Scenarios Run/Oct 2021 MediumCaseScenario/outputs/LC3_LDD_LC1_EBFM.runtimeplot.csv")
plot3<- ggplot(data=current.2100.ns.medium.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.45897,  size=0.5, linetype="dashed")+
  #what land you need to maintain habitat for 100 % of current population in 2100
  geom_vline(xintercept = 0.91243,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 90 % of current population
  geom_vline(xintercept = 0.96193,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 75 % of current population
  geom_vline(xintercept = 0.98593,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in Nova Scotia (Medium case)", y="Proportion of Future Population Left", size=5)+
  annotate("text", x= 0.47, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.93, y = 0.5,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.98, y = 0.5,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 1.0, y = 0.5,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot3, file="2_outputs/Zonation Scenarios Run/Oct 2021 MediumCaseScenario/outputs/LC3_LDD_LC1_EBFM.runtimeplot.png", units="in", width=10, height=8)

current.2100.quebec.worst.rt<-read.csv("2_outputs/Zonation Scenarios Run/Oct 2021 WorstCaseScenario/outputs/LC3_LDD_LC1_EBFM.runtimeplot.csv")
plot4<- ggplot(data=current.2100.quebec.worst.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.44097,  size=0.5, linetype="dashed")+
  #what land you need to maintain habitat for 100 % of current population in 2100
  geom_vline(xintercept = 0.91143,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 90 % of current population
  geom_vline(xintercept = 0.95993,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 75 % of current population
  geom_vline(xintercept = 0.98543,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in Nova Scotia (Worst case)", y="Proportion of Future Population Left", size=5)+
  annotate("text", x= 0.46, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.93, y = 0.5,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.97, y = 0.5,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 1.0, y = 0.5,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot4, file="2_outputs/Zonation Scenarios Run/Oct 2021 WorstCaseScenario/outputs/LC3_LDD_LC1_EBFM.runtimeplot.png", units="in", width=10, height=8)

plot5<-grid.arrange(plot1,plot2,plot3,plot4,nrow=2,ncol=2)
ggsave(plot5, file="2_outputs/Zonation Scenarios Run/Zonation_NovaScotia.runtimeplots.png", units="in", width=12, height=8)
