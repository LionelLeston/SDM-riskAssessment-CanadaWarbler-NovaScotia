#Make a box plot showing projected populations by 2100 under different scenarios
popproj2000.2200<-read.csv("0_data/1_processed/Prediction rasters 2100/bootstrap_predictions2100.csv", header=TRUE)
library(ggplot2)
library(grid)
library(gridExtra)
library(viridis)
library(dplyr)
library(tidyr)

my.theme <- theme_classic() +
  theme(text=element_text(size=8, family="Arial"),
        axis.text.x=element_text(size=8),
        axis.text.y=element_text(size=8),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

my.theme.Xoff <- theme_classic() +
  theme(text=element_text(size=8, family="Arial"),
        axis.text.x=element_blank(),
        axis.text.y=element_text(size=8),
        axis.title.x=element_blank(),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

str(popproj2000.2200)
#'data.frame':	1200 obs. of  10 variables:
# $ X               : int  1 2 3 4 5 6 7 8 9 10 ...
# $ scenario        : chr  "baseline" "baseline" "baseline" "baseline" ...
# $ treatment       : chr  "BudwormBaselineFire" "BudwormBaselineFire" "BudwormBaselineFire" "BudwormBaselineFire" ...
# $ replicate       : int  1 1 1 1 1 1 1 1 1 1 ...
# $ Year            : int  2100 2100 2100 2100 2100 2100 2100 2100 2100 2100 ...
# $ Species         : chr  "CAWA" "CAWA" "CAWA" "CAWA" ...
# $ MeanDensity     : num  0.0228 0.0209 0.0213 0.0216 0.0223 ...
# $ FireTreatment   : chr  "BaselineFire" "BaselineFire" "BaselineFire" "BaselineFire" ...
# $ HarvestTreatment: chr  "" "" "" "" ...
# $ Popsize         : num  59839 54812 55909 56595 58483 ...
levels(as.factor(popproj2000.2200$HarvestTreatment))#6
#[1] ""                   "EBFMHarvest"        "HighCPRSHarvest"   
#[4] "HighPartialHarvest" "LowCPRSHarvest"     "LowPartialHarvest" 

#Recode harvest
popproj2000.2200$HarvestRecode<-NA
popproj2000.2200$HarvestRecode[popproj2000.2200$HarvestTreatment==""]<-"No Harvest"
popproj2000.2200$HarvestRecode[popproj2000.2200$HarvestTreatment=="EBFMHarvest"]<-"EBFM"
popproj2000.2200$HarvestRecode[popproj2000.2200$HarvestTreatment=="HighCPRSHarvest"]<-"Historic Clearcut"
popproj2000.2200$HarvestRecode[popproj2000.2200$HarvestTreatment=="HighPartialHarvest"]<-"Historic Partial"
popproj2000.2200$HarvestRecode[popproj2000.2200$HarvestTreatment=="LowCPRSHarvest"]<-"Half Clearcut"
popproj2000.2200$HarvestRecode[popproj2000.2200$HarvestTreatment=="LowPartialHarvest"]<-"Half Partial"
levels(as.factor(popproj2000.2200$HarvestRecode))
#Relevel harvest code according to percent biomass removed by harvest
popproj2000.2200$HarvestRecode<-as.factor(popproj2000.2200$HarvestRecode)
popproj2000.2200$HarvestRecode<-factor(popproj2000.2200$HarvestRecode, levels=c("No Harvest","Half Partial","Historic Partial","Half Clearcut","EBFM","Historic Clearcut"))
levels(popproj2000.2200$HarvestRecode)


levels(as.factor(popproj2000.2200$FireTreatment))#2
#"BaselineFire"  "ProjectedFire"
levels(as.factor(popproj2000.2200$treatment))#12 (fire*harvest)
# [1] "BudwormBaselineFire"                         
# [2] "BudwormBaselineFireEBFMHarvest"              
# [3] "BudwormBaselineFireHighCPRSHarvest"          
# [4] "BudwormBaselineFireHighPartialHarvest"       
# [5] "BudwormBaselineFireLowCPRSHarvest"           
# [6] "BudwormBaselineFireLowPartialHarvest"        
# [7] "GrowthBudwormProjectedFire"                  
# [8] "GrowthBudwormProjectedFireEBFMHarvest"       
# [9] "GrowthBudwormProjectedFireHighCPRSHarvest"   
# [10] "GrowthBudwormProjectedFireHighPartialHarvest"
# [11] "GrowthBudwormProjectedFireLowCPRSHarvest"    
# [12] "GrowthBudwormProjectedFireLowPartialHarvest" 
levels(as.factor(popproj2000.2200$scenario))#4 (climate)
#"baseline" "RCP26"    "RCP45"    "RCP85"

#there are 24 scenarios: fire treatment is "baseline" under baseline
#scenario and "projected" under RCP 2.6, RCP 4.5, and RCP 8.5
# grouped boxplot

#remove RCP26
popproj2100<-popproj2000.2200[!popproj2000.2200$scenario=="RCP26",]
popproj2100<-popproj2100[!popproj2100$scenario=="RCP26",]

#continuing from script "2_getLandisandBBStrajectories"...
plot22<-ggplot(popproj2100, aes(x=HarvestRecode, y=Popsize, col=scenario, fill=scenario)) + 
  geom_boxplot()+my.theme+xlab("Harvest Scenario")+
  ylab("Projected 2100 Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE, name="Climate Scenario")+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  guides(col=FALSE)
ggsave(plot22, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot22_CAWA2100.box.harvestXclimateL.png", units="in", width=10, height=4)


plot23<-ggplot(popproj2100, aes(x=scenario, y=Popsize, col=HarvestRecode, fill=HarvestRecode)) + 
  geom_boxplot()+my.theme+xlab("Climate Scenario")+
  ylab("Projected 2100 Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE, name="Harvest Scenario")+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  guides(col=FALSE)
ggsave(plot23, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot23_CAWA2100.box.climateXharvestL.png", units="in", width=10, height=4)


plot24<-ggplot(popproj2100, aes(x=HarvestRecode, y=Popsize, col=HarvestRecode, fill=HarvestRecode)) + 
  geom_boxplot()+my.theme+xlab("Harvest Scenario")+
  ylab("Projected 2100 Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE)+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  facet_wrap(~scenario)+
  theme(legend.position = "none")
ggsave(plot24, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot24_CAWA2100.facet.harvestXclimateF.png", units="in", width=10, height=4)


plot25<-ggplot(popproj2100, aes(x=scenario, y=Popsize, col=scenario, fill=scenario)) + 
  geom_boxplot()+my.theme+xlab("Climate Scenario")+
  ylab("Projected 2100 Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE)+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  facet_wrap(~HarvestRecode)+
  theme(legend.position = "none")
ggsave(plot25, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot25_CAWA2100.facet.climateXharvestF.png", units="in", width=10, height=4)

#Summarize population projections in writing: median, mean, CI
pop.summ<-popproj2100 %>%
  group_by(HarvestRecode,scenario) %>%
  summarise(Median=median(Popsize),
            Mean=mean(Popsize),
            Stdev=sd(Popsize),
            Stderr=Stdev/sqrt(250),
            CI.05=Mean-1.96*Stderr,
            CI.95=Mean+1.96*Stderr,
            BCI.05=quantile(Popsize, 0.05),
            BCI.95=quantile(Popsize, 0.95))
pop.summ<-data.frame(pop.summ)
write.csv(pop.summ, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/CAWA2100.PopnSummary.csv")

#Make line plots tracking population change from 2000 to 2200 (using brt5 results, not the bootstrapped model coefficients)

#To do without RCP 26
data<-popproj2000.2200[!popproj2000.2200$scenario=="RCP26",]

plot26<-ggplot(data, aes(x=Year, y=Popsize, col=scenario, fill=scenario)) + 
  geom_line()+  my.theme+xlab("Year")+
  ylab("Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE, name="Climate")+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  guides(col=FALSE, fill=FALSE)+facet_grid(HarvestRecode~scenario)+ 
  stat_smooth(method = "glm", formula = y ~ s(x), size = 1)

ggsave(plot26, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot26_CAWA2000-2200.line.harvestRowXclimateCol.png", units="in", width=10, height=8)

plot27<-ggplot(data, aes(x=Year, y=Popsize, col=scenario, fill=scenario)) + 
  geom_line()+  my.theme+xlab("Year")+
  ylab("Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE, name="Climate")+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  guides(col=FALSE, fill=FALSE)+facet_grid(scenario~HarvestRecode)+ 
  stat_smooth(method = "glm", formula = y ~ s(x), size = 1)

ggsave(plot27, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot27_CAWA2000-2200.line.harvestColXclimateRow.png", units="in", width=10, height=8)

data2<-data[!data$Year>2100,]

plot28<-ggplot(data2, aes(x=Year, y=Popsize, col=scenario, fill=scenario)) + 
  geom_line()+  my.theme+xlab("Year")+
  ylab("Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE, name="Climate")+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  guides(col=FALSE, fill=FALSE)+facet_grid(HarvestRecode~scenario)+ 
  stat_smooth(method = "glm", formula = y ~ s(x), size = 1)

ggsave(plot28, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot28_CAWA2000-2100.line.harvestRowXclimateCol.png", units="in", width=10, height=8)

plot29<-ggplot(data2, aes(x=Year, y=Popsize, col=scenario, fill=scenario)) + 
  geom_line()+  my.theme+xlab("Year")+
  ylab("Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE, name="Climate")+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  guides(col=FALSE, fill=FALSE)+facet_grid(scenario~HarvestRecode)+ 
  stat_smooth(method = "glm", formula = y ~ s(x), size = 1)

ggsave(plot29, file="2_BRT_outputs/GFsigma750m_new/bbs and landis trends/plot29_CAWA2000-2100.line.harvestColXclimateRow.png", units="in", width=10, height=8)
