#The purpose of this script is to show how to obtain
#outputs from the LANDIS-II scenarios run for Canada
#Warbler in northern Nova Scotia. The
#outputs we are interested in will serve as some of the 
#inputs for Zonation scenarios. 

#We are specifically interested in two items from each scenario. 
#First, we need a raster of mean predicted density in 2100.
#Second, we need a raster of the uncertainty (standard
#deviation) in those estimates for each 250-m pixel.
#Uncertainty is due to both BRT sample uncertainty and due to
#simulation runs. So our mean predicted density is based on
#a mean of 5 means (1 per simulation run for each scenario in 2100)
#and our standard deviation is obtained as the square root of
#the sum of 5 standard deviations of 250 density predictions.

#Once we have the necessary raster inputs, we set up a
#Zonation scenario outside of R and ran it. We then
#process some of the Zonation output inside R to generate
#plots the way we like.

#get rasters for each scenario. Each RData file contains 5 rasters (snapshots in time?)
#For each scenario there are 5 RData files (LANDIS runs)
library(maptools)
library(raster)
library(rgdal)
library(sp)
tmp<-getwd()

#Get Current Mean and SD Density Rasters from "2_getLandisandBBStrajectories" script

#rast2 has been saved as "PresentPredictedDensity_mean" to each Zonation project
#SDpreds has been saved as "PresentPredictedDensity_SD" to each Zonation project

#Best Case Scenario
#Baseline Climate Scenario / Historic Clearcuting Rates
for (j in 1:5) {
  load(paste0("0_data/1_processed/Prediction rasters 2100/birddensityr_meansd_BS_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_",j,"_2100_CAWA.RData"))
  M1<-rasterstack_meansd$mean
  r<-raster(M1)
  crs(r)<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
  attributes(r@crs)
  comment(M1@crs)<-comment(r@crs)
  #plot(M1)
  attributes(M1@crs)
  writeRaster(M1, filename=paste0("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_",j,"_Mean.tif"), format='GTiff', overwrite=TRUE)
  
  S1<-rasterstack_meansd$sd
  r2<-raster(S1)
  crs(r2)<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
  attributes(r2@crs)
  comment(S1@crs)<-comment(r2@crs)
  #plot(S1)
  attributes(S1@crs)
  writeRaster(S1, filename=paste0("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_",j,"_sd.tif"), format='GTiff', overwrite=TRUE)
  
}

#create a single mean of means raster for this scenario
M1<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_1_Mean.tif")
M2<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_2_Mean.tif")
M3<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_3_Mean.tif")
M4<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_4_Mean.tif")
M5<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_5_Mean.tif")

Avg.M<-mean(M1,M2,M3,M4,M5)
#plot(Avg.M)
#density 0.0029-0.4131 males or pairs/ha
writeRaster(Avg.M, filename="0_data/1_processed/Rasters for Zonation/ZonationMean_CAWA_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest.tif", format='GTiff', overwrite=TRUE)
writeRaster(Avg.M, filename="0_data/1_processed/Zonation Scenarios Run/Oct 2021 BestCaseScenario/ZonationMean_CAWA_NovaScotia_BestCase.tif", format='GTiff', overwrite=TRUE)

#create a single sd raster for this scenario
S1<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_1_sd.tif")
S2<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_2_sd.tif")
S3<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_3_sd.tif")
S4<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_4_sd.tif")
S5<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_5_sd.tif")

SD<-sqrt(S1^2+S2^2+S3^2+S4^2+S5^2)
#plot(SD)
writeRaster(SD, filename="0_data/1_processed/Rasters for Zonation/ZonationSD_CAWA_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest.tif", format='GTiff', overwrite=TRUE)
writeRaster(SD, filename="0_data/1_processed/Zonation Scenarios Run/Oct 2021 BestCaseScenario/ZonationSD_CAWA_NovaScotia_BestCase.tif", format='GTiff', overwrite=TRUE)

#Worst Case Scenario
#RCP 8.5 / Ecosystem-based Forest Management
for (j in 1:5) {
  load(paste0("0_data/1_processed/Prediction rasters 2100/birddensityr_meansd_BS_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest_",j,"_2100_CAWA.RData"))
  M1<-rasterstack_meansd$mean
  r<-raster(M1)
  crs(r)<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
  attributes(r@crs)
  comment(M1@crs)<-comment(r@crs)
  #plot(M1)
  attributes(M1@crs)
  writeRaster(M1, filename=paste0("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest_",j,"_Mean.tif"), format='GTiff', overwrite=TRUE)
  
  S1<-rasterstack_meansd$sd
  r2<-raster(S1)
  crs(r2)<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
  attributes(r2@crs)
  comment(S1@crs)<-comment(r2@crs)
  #plot(S1)
  attributes(S1@crs)
  writeRaster(S1, filename=paste0("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest_",j,"_sd.tif"), format='GTiff', overwrite=TRUE)
  
}

#create a single mean of means raster for this scenario
M1<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest_1_Mean.tif")
M2<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest_2_Mean.tif")
M3<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest_3_Mean.tif")
M4<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest_4_Mean.tif")
M5<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest_5_Mean.tif")

Avg.M<-mean(M1,M2,M3,M4,M5)
#plot(Avg.M)
#density 0.0021-0.364 males or pairs per ha
writeRaster(Avg.M, filename="0_data/1_processed/Rasters for Zonation/ZonationMean_CAWA_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest.tif", format='GTiff', overwrite=TRUE)
writeRaster(Avg.M, filename="0_data/1_processed/Zonation Scenarios Run/Oct 2021 WorstCaseScenario/ZonationMean_CAWA_NovaScotia_WorstCase.tif", format='GTiff', overwrite=TRUE)

#create a single sd raster for this scenario
S1<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest_1_sd.tif")
S2<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest_2_sd.tif")
S3<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest_3_sd.tif")
S4<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest_4_sd.tif")
S5<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest_5_sd.tif")

SD<-sqrt(S1^2+S2^2+S3^2+S4^2+S5^2)
#plot(SD)
writeRaster(SD, filename="0_data/1_processed/Rasters for Zonation/ZonationSD_CAWA_NovaScotia_RCP85_GrowthBudwormProjectedFireEBFMHarvest.tif", format='GTiff', overwrite=TRUE)
writeRaster(SD, filename="0_data/1_processed/Zonation Scenarios Run/Oct 2021 WorstCaseScenario/ZonationSD_CAWA_NovaScotia_WorstCase.tif", format='GTiff', overwrite=TRUE)

#Middle-Case Scenario
#RCP 4.5 / Ecosystem-based Forest Management
for (j in 1:5) {
  load(paste0("0_data/1_processed/Prediction rasters 2100/birddensityr_meansd_BS_NovaScotia_RCP45_GrowthBudwormProjectedFireEBFMHarvest_",j,"_2100_CAWA.RData"))
  M1<-rasterstack_meansd$mean
  r<-raster(M1)
  crs(r)<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
  attributes(r@crs)
  comment(M1@crs)<-comment(r@crs)
  #plot(M1)
  attributes(M1@crs)
  writeRaster(M1, filename=paste0("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP45_GrowthBudwormProjectedFireEBFMHarvest_",j,"_Mean.tif"), format='GTiff', overwrite=TRUE)
  
  S1<-rasterstack_meansd$sd
  r2<-raster(S1)
  crs(r2)<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
  attributes(r2@crs)
  comment(S1@crs)<-comment(r2@crs)
  #plot(S1)
  attributes(S1@crs)
  writeRaster(S1, filename=paste0("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP45_GrowthBudwormProjectedFireEBFMHarvest_",j,"_sd.tif"), format='GTiff', overwrite=TRUE)
  
}

#create a single mean of means raster for this scenario
M1<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP45_GrowthBudwormProjectedFireEBFMHarvest_1_Mean.tif")
M2<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP45_GrowthBudwormProjectedFireEBFMHarvest_2_Mean.tif")
M3<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP45_GrowthBudwormProjectedFireEBFMHarvest_3_Mean.tif")
M4<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP45_GrowthBudwormProjectedFireEBFMHarvest_4_Mean.tif")
M5<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP45_GrowthBudwormProjectedFireEBFMHarvest_5_Mean.tif")

Avg.M<-mean(M1,M2,M3,M4,M5)
#plot(Avg.M)
#density 0.0020-0.4489 males or pairs/ha
writeRaster(Avg.M, filename="0_data/1_processed/Rasters for Zonation/ZonationMean_CAWA_NovaScotia_RCP45_GrowthBudwormProjectedFireEBFMHarvest.tif", format='GTiff', overwrite=TRUE)
writeRaster(Avg.M, filename="0_data/1_processed/Zonation Scenarios Run/Oct 2021 MediumCaseScenario/ZonationMean_CAWA_NovaScotia_MediumCase.tif", format='GTiff', overwrite=TRUE)

#create a single sd raster for this scenario
S1<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP45_GrowthBudwormProjectedFireEBFMHarvest_1_sd.tif")
S2<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP45_GrowthBudwormProjectedFireEBFMHarvest_2_sd.tif")
S3<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP45_GrowthBudwormProjectedFireEBFMHarvest_3_sd.tif")
S4<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP45_GrowthBudwormProjectedFireEBFMHarvest_4_sd.tif")
S5<-raster("0_data/1_processed/Rasters for Zonation/CAWA_NovaScotia_RCP45_GrowthBudwormProjectedFireEBFMHarvest_5_sd.tif")

SD<-sqrt(S1^2+S2^2+S3^2+S4^2+S5^2)
#plot(SD)
writeRaster(SD, filename="0_data/1_processed/Rasters for Zonation/ZonationSD_CAWA_NovaScotia_RCP45_GrowthBudwormProjectedFireEBFMHarvest.tif", format='GTiff', overwrite=TRUE)
writeRaster(SD, filename="0_data/1_processed/Zonation Scenarios Run/Oct 2021 MediumCaseScenario/ZonationSD_CAWA_NovaScotia_MediumCase.tif", format='GTiff', overwrite=TRUE)

#Get point count occurrence locations for northern Nova Scotia and
#pass them to each Zonation project

SSI_CAWA_CH_NS<-datcombo[,c("X","Y","ABUND")]
str(SSI_CAWA_CH_NS)#15059
SSI_CAWA_CH_NS<-SSI_CAWA_CH_NS[SSI_CAWA_CH_NS$ABUND>0,]
str(SSI_CAWA_CH_NS)#193
#Now get rid of the points outside the Landis scenarios in Nova Scotia
extent(Avg.M)
#class      : Extent 
#xmin       : 2300250 
#xmax       : 2628750 
#ymin       : 6679500 
#ymax       : 7069000 
SSI_CAWA_CH_NS.b<-SSI_CAWA_CH_NS[!SSI_CAWA_CH_NS$X<2300250,]
SSI_CAWA_CH_NS.c<-SSI_CAWA_CH_NS.b[!SSI_CAWA_CH_NS.b$X>2628750,]
SSI_CAWA_CH_NS.d<-SSI_CAWA_CH_NS.c[!SSI_CAWA_CH_NS.c$Y<6679500,]
SSI_CAWA_CH_NS.e<-SSI_CAWA_CH_NS.d[!SSI_CAWA_CH_NS.d$Y>7069000,]
write.csv(SSI_CAWA_CH_NS.e, file="0_data/1_processed/Zonation Scenarios Run/SSI_CAWA_CH_NS.csv")
#strip header from this file, add a fourth column of all zeros, then save as text file
#remove CAWA occurrences outside of Nova Scotia Landis II extent
#Then copy text file to each Zonation project folder in
#"0_data/1_processed/Zonation Scenarios Run"


